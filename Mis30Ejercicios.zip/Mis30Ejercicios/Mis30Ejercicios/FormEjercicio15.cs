﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mis30Ejercicios
{
    public partial class FormEjercicio15 : Form
    {
        public FormEjercicio15()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            long suma = 0; 
            long producto = 1;
            bool productoValido = true;

            for (int x = 20; x <= 400; x += 2)
            {
                suma += x;
                if (productoValido)
                {
                    try
                    {
                        checked { producto *= x; } 
                    }
                    catch (OverflowException)
                    {
                        productoValido = false;
                        producto = 0; 
                    }
                }
            }

            lblSuma.Text = $"Suma: {suma}";
            lblProducto.Text = productoValido ? $"Producto: {producto}" : "Producto: Desbordamiento (número demasiado grande)";
        }
    }
}
