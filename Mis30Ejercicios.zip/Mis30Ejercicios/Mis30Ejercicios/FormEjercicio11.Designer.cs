﻿namespace Mis30Ejercicios
{
    partial class FormEjercicio11
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormEjercicio11));
            label1 = new Label();
            lblPrecio = new Label();
            txtPrecio = new TextBox();
            txtCantidad = new TextBox();
            lblCantidad = new Label();
            btnCalcular = new Button();
            lblResultado = new Label();
            btnLimpiar = new Button();
            button1 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Pink;
            label1.Font = new Font("Sylfaen", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(193, 56);
            label1.Name = "label1";
            label1.Size = new Size(179, 25);
            label1.TabIndex = 0;
            label1.Text = "Factura de Compra";
            label1.Click += label1_Click;
            // 
            // lblPrecio
            // 
            lblPrecio.AutoSize = true;
            lblPrecio.BackColor = Color.Transparent;
            lblPrecio.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            lblPrecio.Location = new Point(146, 109);
            lblPrecio.Name = "lblPrecio";
            lblPrecio.Size = new Size(58, 22);
            lblPrecio.TabIndex = 1;
            lblPrecio.Text = "Precio";
            // 
            // txtPrecio
            // 
            txtPrecio.BackColor = Color.Pink;
            txtPrecio.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            txtPrecio.Location = new Point(227, 106);
            txtPrecio.Name = "txtPrecio";
            txtPrecio.Size = new Size(103, 29);
            txtPrecio.TabIndex = 2;
            // 
            // txtCantidad
            // 
            txtCantidad.BackColor = Color.Pink;
            txtCantidad.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            txtCantidad.Location = new Point(227, 177);
            txtCantidad.Name = "txtCantidad";
            txtCantidad.Size = new Size(103, 29);
            txtCantidad.TabIndex = 3;
            // 
            // lblCantidad
            // 
            lblCantidad.AutoSize = true;
            lblCantidad.BackColor = Color.Transparent;
            lblCantidad.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            lblCantidad.Location = new Point(128, 180);
            lblCantidad.Name = "lblCantidad";
            lblCantidad.Size = new Size(76, 22);
            lblCantidad.TabIndex = 4;
            lblCantidad.Text = "Cantidad";
            // 
            // btnCalcular
            // 
            btnCalcular.BackColor = Color.Pink;
            btnCalcular.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            btnCalcular.Location = new Point(353, 260);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(83, 29);
            btnCalcular.TabIndex = 5;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = false;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.BackColor = Color.Pink;
            lblResultado.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            lblResultado.Location = new Point(387, 106);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(90, 22);
            lblResultado.TabIndex = 6;
            lblResultado.Text = "Resultados";
            // 
            // btnLimpiar
            // 
            btnLimpiar.BackColor = Color.Pink;
            btnLimpiar.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            btnLimpiar.Location = new Point(252, 260);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(78, 29);
            btnLimpiar.TabIndex = 7;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = false;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Pink;
            button1.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            button1.Location = new Point(158, 260);
            button1.Name = "button1";
            button1.Size = new Size(78, 29);
            button1.TabIndex = 8;
            button1.Text = "Volver";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // FormEjercicio11
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(633, 350);
            Controls.Add(button1);
            Controls.Add(btnLimpiar);
            Controls.Add(lblResultado);
            Controls.Add(btnCalcular);
            Controls.Add(lblCantidad);
            Controls.Add(txtCantidad);
            Controls.Add(txtPrecio);
            Controls.Add(lblPrecio);
            Controls.Add(label1);
            Name = "FormEjercicio11";
            Text = "FormEjercicio11";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label lblPrecio;
        private TextBox txtPrecio;
        private TextBox txtCantidad;
        private Label lblCantidad;
        private Button btnCalcular;
        private Label lblResultado;
        private Button btnLimpiar;
        private Button button1;
    }
}