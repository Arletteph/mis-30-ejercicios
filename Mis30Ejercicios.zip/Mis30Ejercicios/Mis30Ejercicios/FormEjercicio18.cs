﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mis30Ejercicios
{
    public partial class FormEjercicio18 : Form
    {
        public FormEjercicio18()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtCoefA.Text, out double a) &&
                double.TryParse(txtCoefB.Text, out double b) &&
                double.TryParse(txtCoefC.Text, out double c))
            {
                if (a == 0)
                {
                    lblResultado.Text = "Error: 'a' no puede ser cero (no es cuadrática).";
                    return;
                }

                double discriminante = Math.Pow(b, 2) - 4 * a * c;
                string resultado;

                if (discriminante > 0)
                {
                    double x1 = Math.Round((-b + Math.Sqrt(discriminante)) / (2 * a), 2);
                    double x2 = Math.Round((-b - Math.Sqrt(discriminante)) / (2 * a), 2);
                    resultado = $"Raíces reales:\nX₁ = {x1}\nX₂ = {x2}";
                }
                else if (discriminante == 0)
                {
                    double x = Math.Round(-b / (2 * a), 2);
                    resultado = $"Raíz única (doble):\nX = {x}";
                }
                else
                {
                    double parteReal = Math.Round(-b / (2 * a), 2);
                    double parteImag = Math.Round(Math.Sqrt(-discriminante) / (2 * a), 2);
                    resultado = $"Raíces complejas:\nX₁ = {parteReal} + {parteImag}i\nX₂ = {parteReal} - {parteImag}i";
                }

                lblResultado.Text = $"Discriminante: {discriminante}\n{resultado}";
            }
            else
            {
                MessageBox.Show("Ingrese coeficientes válidos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtCoefA.Clear();
            txtCoefB.Clear();
            txtCoefC.Clear();
            lblResultado.Text = "Resultado";
            txtCoefA.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

}
