﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mis30Ejercicios
{
    public partial class FormEjercicio22 : Form
    {
        public FormEjercicio22()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtLadoA.Text, out double ladoA) &&
                double.TryParse(txtLadoB.Text, out double ladoB) &&
                double.TryParse(txtLadoC.Text, out double ladoC))
            {

                if (ladoA <= 0 || ladoB <= 0 || ladoC <= 0)
                {
                    lblResultado.Text = "Error: Todos los lados deben ser mayores a cero.";
                    lblResultado.ForeColor = Color.Red;
                    return;
                }


                if (ladoA + ladoB <= ladoC || ladoA + ladoC <= ladoB || ladoB + ladoC <= ladoA)
                {
                    lblResultado.Text = "Error: Los lados no forman un triángulo válido.";
                    
                    return;
                }


                double semiPerimetro = (ladoA + ladoB + ladoC) / 2;
                double area = Math.Sqrt(semiPerimetro * (semiPerimetro - ladoA) * (semiPerimetro - ladoB) * (semiPerimetro - ladoC));

                lblResultado.Text = $"Área del triángulo: {Math.Round(area, 2)}";
                
            }
            else
            {
                MessageBox.Show("Ingrese valores numéricos válidos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
            lblResultado.Text = "Resultado";
            txtLadoA.Focus();
        }
    }

}
