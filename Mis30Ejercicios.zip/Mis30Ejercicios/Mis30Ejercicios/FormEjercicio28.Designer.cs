﻿namespace Mis30Ejercicios
{
    partial class FormEjercicio28
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtNota1 = new TextBox();
            txtNota2 = new TextBox();
            btnLimpiar = new Button();
            Volver = new Button();
            btnCacular = new Button();
            lblPromedio = new Label();
            lblComentario = new Label();
            label2 = new Label();
            label3 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(123, 78);
            label1.Name = "label1";
            label1.Size = new Size(234, 30);
            label1.TabIndex = 0;
            label1.Text = "Notas con Comentario";
            // 
            // txtNota1
            // 
            txtNota1.Location = new Point(172, 162);
            txtNota1.Name = "txtNota1";
            txtNota1.Size = new Size(100, 23);
            txtNota1.TabIndex = 1;
            // 
            // txtNota2
            // 
            txtNota2.Location = new Point(172, 191);
            txtNota2.Name = "txtNota2";
            txtNota2.Size = new Size(100, 23);
            txtNota2.TabIndex = 2;
            // 
            // btnLimpiar
            // 
            btnLimpiar.BackColor = Color.Khaki;
            btnLimpiar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            btnLimpiar.Location = new Point(182, 268);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(75, 29);
            btnLimpiar.TabIndex = 4;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = false;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // Volver
            // 
            Volver.BackColor = Color.Khaki;
            Volver.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            Volver.Location = new Point(86, 270);
            Volver.Name = "Volver";
            Volver.Size = new Size(75, 27);
            Volver.TabIndex = 7;
            Volver.Text = "Volver";
            Volver.UseVisualStyleBackColor = false;
            Volver.Click += Volver_Click;
            // 
            // btnCacular
            // 
            btnCacular.BackColor = Color.Khaki;
            btnCacular.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            btnCacular.Location = new Point(282, 270);
            btnCacular.Name = "btnCacular";
            btnCacular.Size = new Size(75, 24);
            btnCacular.TabIndex = 5;
            btnCacular.Text = "Calcular";
            btnCacular.UseVisualStyleBackColor = false;
            btnCacular.Click += btnCacular_Click;
            // 
            // lblPromedio
            // 
            lblPromedio.AutoSize = true;
            lblPromedio.BackColor = Color.Transparent;
            lblPromedio.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            lblPromedio.Location = new Point(305, 160);
            lblPromedio.Name = "lblPromedio";
            lblPromedio.Size = new Size(68, 17);
            lblPromedio.TabIndex = 8;
            lblPromedio.Text = "Promedio";
            // 
            // lblComentario
            // 
            lblComentario.AutoSize = true;
            lblComentario.BackColor = Color.Transparent;
            lblComentario.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            lblComentario.Location = new Point(305, 197);
            lblComentario.Name = "lblComentario";
            lblComentario.Size = new Size(80, 17);
            lblComentario.TabIndex = 9;
            lblComentario.Text = "Comentario";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label2.Location = new Point(86, 162);
            label2.Name = "label2";
            label2.Size = new Size(44, 15);
            label2.TabIndex = 10;
            label2.Text = "Nota 1";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label3.Location = new Point(86, 199);
            label3.Name = "label3";
            label3.Size = new Size(44, 15);
            label3.TabIndex = 11;
            label3.Text = "Nota 2";
            // 
            // FormEjercicio28
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.descarga__33_;
            ClientSize = new Size(574, 343);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(lblComentario);
            Controls.Add(lblPromedio);
            Controls.Add(Volver);
            Controls.Add(btnCacular);
            Controls.Add(btnLimpiar);
            Controls.Add(txtNota2);
            Controls.Add(txtNota1);
            Controls.Add(label1);
            Name = "FormEjercicio28";
            Text = "FormEjercicio28";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtNota1;
        private TextBox txtNota2;
        private Button btnLimpiar;
        private Button Volver;
        private Button btnCacular;
        private Label lblPromedio;
        private Label lblComentario;
        private Label label2;
        private Label label3;
    }
}