﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mis30Ejercicios
{
    public partial class FormEjercicio09 : Form
    {
        private List<double> notas = new List<double>();
        private int aprobadas = 0, desaprobadas = 0;
        private double sumaTotal = 0, sumaAprobadas = 0, sumaDesaprobadas = 0;
        public FormEjercicio09()
        {
            InitializeComponent();
        }

        private void volver_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAgregarNota_Click(object sender, EventArgs e)
        {

            if (double.TryParse(txtNotas.Text, out double nota) && nota >= 0 && nota <= 20)
            {
                // Agregar nota a la lista
                lstNotas.Items.Add(nota);

                // Clasificar nota
                if (nota > 10.5)
                {
                    aprobadas++;
                    sumaAprobadas += nota;
                }
                else
                {
                    desaprobadas++;
                    sumaDesaprobadas += nota;
                }
                sumaTotal += nota;

                txtNotas.Clear();
            }
            else
            {
                MessageBox.Show("Ingrese una nota válida (0-20).", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {

            if (aprobadas + desaprobadas == 0)
            {
                MessageBox.Show("No hay notas ingresadas.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Calcular promedios
            double promedioGeneral = Math.Round(sumaTotal / (aprobadas + desaprobadas), 1);
            double promedioAprob = aprobadas > 0 ? Math.Round(sumaAprobadas / aprobadas, 1) : 0;
            double promedioDesaprob = desaprobadas > 0 ? Math.Round(sumaDesaprobadas / desaprobadas, 1) : 0;


            lblAprobadas.Text = $"Aprobadas: {aprobadas}";
            lblDesaprobadas.Text = $"Reprobadas: {desaprobadas}";
            lblPromedioGeneral.Text = $"Promedio General: {promedioGeneral}";
            lblPromedioAprobadas.Text = $"Promedio Aprobadas: {promedioAprob}";
            lblPromedioreprobadas.Text = $"Promedio Reprobadas: {promedioDesaprob}";
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {

            sumaTotal = 0;
            aprobadas = 0;
            desaprobadas = 0;
            sumaAprobadas = 0;
            sumaDesaprobadas = 0;

            txtNotas.Clear();
            lstNotas.Items.Clear();


            lblAprobadas.Text = "Aprobadas: 0";
            lblDesaprobadas.Text = "Desaprobadas: 0";
            lblPromedioGeneral.Text = "Promedio General: 0.0";
            lblPromedioAprobadas.Text = "Promedio Aprobadas: 0.0";
            lblPromedioreprobadas.Text = "Promedio Desaprobadas: 0.0";
        }


       
    }
    
}



