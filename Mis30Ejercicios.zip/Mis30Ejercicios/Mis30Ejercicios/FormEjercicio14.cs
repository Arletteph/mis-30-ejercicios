﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mis30Ejercicios
{
    public partial class FormEjercicio14 : Form
    {
        private double suma = 0;
        private int contador = 0;
        public FormEjercicio14()
        {
            InitializeComponent();
        }

        private void btnAgregarNumeros_Click(object sender, EventArgs e)
        {
            if (contador >= 100)
            {
                MessageBox.Show("Ya ingresaste 100 números.", "Fin", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (double.TryParse(txtNumero.Text, out double numero))
            {
                suma += numero;
                contador++;
                lblContador.Text = $"Ingresados: {contador}/100";
                txtNumero.Clear();

                if (contador == 100)
                {
                    double media = Math.Round(suma / 100, 2);
                    lblResultado.Text = $"Media: {media}";
                }
            }
            else
            {
                MessageBox.Show("Ingrese un número válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            suma = 0;
            contador = 0;
            txtNumero.Clear();
            lblContador.Text = "Ingresados: 0/100";
            lblResultado.Text = "Media: ";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
