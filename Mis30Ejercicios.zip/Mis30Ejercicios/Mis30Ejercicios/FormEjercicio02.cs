﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Mis30Ejercicios
{
    public partial class FormEjercicio02 : Form
    {
        public FormEjercicio02()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Validar sueldo 
            if (!double.TryParse(textBox1.Text, out double sueldo) || sueldo < 0)
            {
                MessageBox.Show("Ingrese un sueldo válido.", "Error");
                return;
            }

            
            string moneda = cmbMoneda.SelectedItem.ToString();

           
            double descuento;
            if (sueldo <= 1000)
                descuento = sueldo * 0.1;
            else if (sueldo <= 2000)
                descuento = (sueldo - 1000) * 0.05 + 100;
            else
                descuento = (sueldo - 2000) * 0.03 + 150;

            double sueldoNeto = sueldo - descuento;

            // Mostrar resultados con moneda
            label2.Text = $@"Sueldo Bruto: {sueldo:C2} ({moneda})
    Descuento: {descuento:C2}
    Sueldo Neto: {sueldoNeto:C2}";
        } 

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            label1.Text = "Descuento: $0.00";
            label2.Text = "Sueldo Neto: $0.00";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbMoneda.Items.AddRange(new object[] { "Pesos", "Dólares", "Euros" });
            cmbMoneda.SelectedIndex = 0; 

            
            dtpFecha.Value = DateTime.Today;
        }
    }
}
