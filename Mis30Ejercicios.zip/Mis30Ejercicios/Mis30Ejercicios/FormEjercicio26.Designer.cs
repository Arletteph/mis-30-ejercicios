﻿namespace Mis30Ejercicios
{
    partial class FormEjercicio26
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtNumeroN = new TextBox();
            btnCalcular = new Button();
            button1 = new Button();
            btnLimpiar = new Button();
            lblResultado = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(95, 86);
            label1.Name = "label1";
            label1.Size = new Size(249, 25);
            label1.TabIndex = 0;
            label1.Text = "Suma de Números desde 8";
            // 
            // txtNumeroN
            // 
            txtNumeroN.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            txtNumeroN.Location = new Point(178, 152);
            txtNumeroN.Name = "txtNumeroN";
            txtNumeroN.Size = new Size(100, 25);
            txtNumeroN.TabIndex = 1;
            // 
            // btnCalcular
            // 
            btnCalcular.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            btnCalcular.Location = new Point(295, 219);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(75, 23);
            btnCalcular.TabIndex = 2;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            button1.Location = new Point(95, 219);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 3;
            button1.Text = "Volver";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // btnLimpiar
            // 
            btnLimpiar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            btnLimpiar.Location = new Point(191, 219);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(75, 23);
            btnLimpiar.TabIndex = 4;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = true;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.BackColor = Color.Transparent;
            lblResultado.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            lblResultado.Location = new Point(284, 155);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(69, 17);
            lblResultado.TabIndex = 5;
            lblResultado.Text = "Resultado";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            label2.Location = new Point(12, 155);
            label2.Name = "label2";
            label2.Size = new Size(160, 17);
            label2.TabIndex = 6;
            label2.Text = "Ingresa el número limite";
            // 
            // FormEjercicio26
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.spring_and_summer_girl_wallpaper;
            ClientSize = new Size(495, 325);
            Controls.Add(label2);
            Controls.Add(lblResultado);
            Controls.Add(btnLimpiar);
            Controls.Add(button1);
            Controls.Add(btnCalcular);
            Controls.Add(txtNumeroN);
            Controls.Add(label1);
            Name = "FormEjercicio26";
            Text = "FormEjercicio26";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtNumeroN;
        private Button btnCalcular;
        private Button button1;
        private Button btnLimpiar;
        private Label lblResultado;
        private Label label2;
    }
}