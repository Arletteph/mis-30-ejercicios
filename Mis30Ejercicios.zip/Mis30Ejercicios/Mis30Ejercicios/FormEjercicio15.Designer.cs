﻿namespace Mis30Ejercicios
{
    partial class FormEjercicio15
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnCalcular = new Button();
            lblSuma = new Label();
            lblProducto = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // btnCalcular
            // 
            btnCalcular.BackColor = Color.PaleTurquoise;
            btnCalcular.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnCalcular.Location = new Point(264, 249);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(92, 33);
            btnCalcular.TabIndex = 0;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = false;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // lblSuma
            // 
            lblSuma.AutoSize = true;
            lblSuma.BackColor = Color.PaleTurquoise;
            lblSuma.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lblSuma.Location = new Point(145, 170);
            lblSuma.Name = "lblSuma";
            lblSuma.Size = new Size(53, 21);
            lblSuma.TabIndex = 1;
            lblSuma.Text = "Suma";
            // 
            // lblProducto
            // 
            lblProducto.AutoSize = true;
            lblProducto.BackColor = Color.PaleTurquoise;
            lblProducto.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lblProducto.Location = new Point(388, 170);
            lblProducto.Name = "lblProducto";
            lblProducto.Size = new Size(80, 21);
            lblProducto.TabIndex = 2;
            lblProducto.Text = "Producto";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(122, 83);
            label1.Name = "label1";
            label1.Size = new Size(365, 30);
            label1.TabIndex = 3;
            label1.Text = " Suma y Producto de Pares (20-400)";
            // 
            // FormEjercicio15
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.alice;
            ClientSize = new Size(652, 329);
            Controls.Add(label1);
            Controls.Add(lblProducto);
            Controls.Add(lblSuma);
            Controls.Add(btnCalcular);
            Name = "FormEjercicio15";
            Text = "FormEjercicio15";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnCalcular;
        private Label lblSuma;
        private Label lblProducto;
        private Label label1;
    }
}