﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mis30Ejercicios
{
    public partial class FormEjercicio04 : Form
    {
        public FormEjercicio04()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtSegundos.Text, out int segundos) && segundos > 0)
            {
                if (segundos < 60)
                {
                    int segundosFaltantes = 60 - segundos;
                    // Actualiza el reloj (00:ss)
                    lblReloj.Text = $"00:{segundos:D2}"; // ← Línea nueva
                    lblResultado.Text = $"Faltan {segundosFaltantes} segundos para 1 minuto.";
                }
                else
                {
                    int minutos = segundos / 60;
                    int segundosRestantes = segundos % 60;
                    int segundosFaltantes = 60 - segundosRestantes;
                    // Actualiza el reloj (mm:ss)
                    lblReloj.Text = $"{minutos:D2}:{segundosRestantes:D2}"; // ← Línea nueva
                    lblResultado.Text = $"Equivale a {minutos} minutos y faltan {segundosFaltantes} segundos para el siguiente minuto.";
                }
            }
            else
            {
                MessageBox.Show("Ingrese un número entero positivo.", "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void lblReloj_Click(object sender, EventArgs e)
        {
            lblReloj.TextAlign = ContentAlignment.MiddleCenter; 
            lblReloj.AutoSize = false; // Permite redimensionar
            lblReloj.Text = "00:00"; 
        }

        private void button1_Click(object sender, EventArgs e)
        {
        
           
            txtSegundos.Clear(); 
            lblReloj.Text = "00:00";
            lblResultado.Text = "Resultado:";
           

            // 5. Enfocar el TextBox para nueva entrada
            txtSegundos.Focus();
        }
    }
    

}
