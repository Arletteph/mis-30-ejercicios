﻿namespace Mis30Ejercicios
{
    partial class FormEjercicio03
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtMonto = new TextBox();
            btnCalcular = new Button();
            lblDescuento = new Label();
            lblMonto = new Label();
            lblTotal = new Label();
            button1 = new Button();
            button2 = new Button();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // txtMonto
            // 
            txtMonto.Location = new Point(211, 144);
            txtMonto.Name = "txtMonto";
            txtMonto.Size = new Size(132, 23);
            txtMonto.TabIndex = 0;
            // 
            // btnCalcular
            // 
            btnCalcular.BackColor = SystemColors.GradientActiveCaption;
            btnCalcular.Font = new Font("Sylfaen", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCalcular.Location = new Point(236, 232);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(86, 38);
            btnCalcular.TabIndex = 1;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = false;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // lblDescuento
            // 
            lblDescuento.AutoSize = true;
            lblDescuento.BackColor = SystemColors.GradientActiveCaption;
            lblDescuento.BorderStyle = BorderStyle.FixedSingle;
            lblDescuento.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold);
            lblDescuento.Location = new Point(371, 147);
            lblDescuento.Name = "lblDescuento";
            lblDescuento.Size = new Size(79, 20);
            lblDescuento.TabIndex = 2;
            lblDescuento.Text = "Descuento:";
            // 
            // lblMonto
            // 
            lblMonto.AutoSize = true;
            lblMonto.BackColor = SystemColors.GradientActiveCaption;
            lblMonto.BorderStyle = BorderStyle.FixedSingle;
            lblMonto.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold);
            lblMonto.Location = new Point(371, 118);
            lblMonto.Name = "lblMonto";
            lblMonto.Size = new Size(57, 20);
            lblMonto.TabIndex = 3;
            lblMonto.Text = "Monto:";
            // 
            // lblTotal
            // 
            lblTotal.AutoSize = true;
            lblTotal.BackColor = SystemColors.GradientActiveCaption;
            lblTotal.BorderStyle = BorderStyle.FixedSingle;
            lblTotal.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold);
            lblTotal.Location = new Point(371, 178);
            lblTotal.Name = "lblTotal";
            lblTotal.Size = new Size(47, 20);
            lblTotal.TabIndex = 4;
            lblTotal.Text = "Total:";
            // 
            // button1
            // 
            button1.BackColor = SystemColors.GradientActiveCaption;
            button1.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            button1.Location = new Point(338, 232);
            button1.Name = "button1";
            button1.Size = new Size(80, 39);
            button1.TabIndex = 5;
            button1.Text = "Limpiar";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.GradientActiveCaption;
            button2.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            button2.Location = new Point(150, 232);
            button2.Name = "button2";
            button2.Size = new Size(80, 39);
            button2.TabIndex = 6;
            button2.Text = "Volver";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.GradientActiveCaption;
            label1.BorderStyle = BorderStyle.FixedSingle;
            label1.Font = new Font("Sylfaen", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(142, 76);
            label1.Name = "label1";
            label1.Size = new Size(276, 24);
            label1.TabIndex = 7;
            label1.Text = "Calculadora de Descuentos Rápidos";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = SystemColors.GradientActiveCaption;
            label2.BorderStyle = BorderStyle.FixedSingle;
            label2.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(89, 147);
            label2.Name = "label2";
            label2.Size = new Size(116, 20);
            label2.TabIndex = 8;
            label2.Text = "Ingrese el monto";
            // 
            // FormEjercicio03
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.AF15170;
            ClientSize = new Size(587, 350);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(lblTotal);
            Controls.Add(lblMonto);
            Controls.Add(lblDescuento);
            Controls.Add(btnCalcular);
            Controls.Add(txtMonto);
            Name = "FormEjercicio03";
            Text = "FormEjercicio03";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtMonto;
        private Button btnCalcular;
        private Label lblDescuento;
        private Label lblMonto;
        private Label lblTotal;
        private Button button1;
        private Button button2;
        private Label label1;
        private Label label2;
    }
}