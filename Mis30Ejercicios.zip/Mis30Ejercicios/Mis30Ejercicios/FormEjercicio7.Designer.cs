﻿namespace Mis30Ejercicios
{
    partial class FormEjercicio7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormEjercicio7));
            txtNumTrabajadores = new TextBox();
            txtHoras = new TextBox();
            txtTarifa = new TextBox();
            btnAgregar = new Button();
            btnCalcularSuma = new Button();
            lblSumaTotal = new Label();
            lstTrabajadores = new ListBox();
            btnLimpiar = new Button();
            button1 = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            SuspendLayout();
            // 
            // txtNumTrabajadores
            // 
            txtNumTrabajadores.Location = new Point(272, 127);
            txtNumTrabajadores.Name = "txtNumTrabajadores";
            txtNumTrabajadores.Size = new Size(100, 23);
            txtNumTrabajadores.TabIndex = 0;
            txtNumTrabajadores.TextChanged += txtNumTrabajadores_TextChanged;
            // 
            // txtHoras
            // 
            txtHoras.Location = new Point(269, 189);
            txtHoras.Name = "txtHoras";
            txtHoras.Size = new Size(100, 23);
            txtHoras.TabIndex = 1;
            // 
            // txtTarifa
            // 
            txtTarifa.Location = new Point(273, 249);
            txtTarifa.Name = "txtTarifa";
            txtTarifa.Size = new Size(100, 23);
            txtTarifa.TabIndex = 2;
            // 
            // btnAgregar
            // 
            btnAgregar.BackColor = Color.Khaki;
            btnAgregar.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            btnAgregar.Location = new Point(396, 122);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(172, 37);
            btnAgregar.TabIndex = 3;
            btnAgregar.Text = "Agregar Trabajador";
            btnAgregar.UseVisualStyleBackColor = false;
            btnAgregar.Click += btnAgregar_Click;
            // 
            // btnCalcularSuma
            // 
            btnCalcularSuma.BackColor = Color.Khaki;
            btnCalcularSuma.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            btnCalcularSuma.Location = new Point(396, 180);
            btnCalcularSuma.Name = "btnCalcularSuma";
            btnCalcularSuma.Size = new Size(95, 37);
            btnCalcularSuma.TabIndex = 4;
            btnCalcularSuma.Text = "Calcular";
            btnCalcularSuma.UseVisualStyleBackColor = false;
            btnCalcularSuma.Click += btnCalcularSuma_Click;
            // 
            // lblSumaTotal
            // 
            lblSumaTotal.AutoSize = true;
            lblSumaTotal.BackColor = Color.Khaki;
            lblSumaTotal.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblSumaTotal.Location = new Point(396, 250);
            lblSumaTotal.Name = "lblSumaTotal";
            lblSumaTotal.Size = new Size(69, 18);
            lblSumaTotal.TabIndex = 5;
            lblSumaTotal.Text = "Resultado";
            // 
            // lstTrabajadores
            // 
            lstTrabajadores.FormattingEnabled = true;
            lstTrabajadores.ItemHeight = 15;
            lstTrabajadores.Location = new Point(12, 27);
            lstTrabajadores.Name = "lstTrabajadores";
            lstTrabajadores.Size = new Size(120, 94);
            lstTrabajadores.TabIndex = 6;
            // 
            // btnLimpiar
            // 
            btnLimpiar.BackColor = Color.Khaki;
            btnLimpiar.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            btnLimpiar.Location = new Point(380, 303);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(85, 37);
            btnLimpiar.TabIndex = 7;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = false;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Khaki;
            button1.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            button1.Location = new Point(115, 303);
            button1.Name = "button1";
            button1.Size = new Size(78, 37);
            button1.TabIndex = 8;
            button1.Text = "Volver";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Khaki;
            label1.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold);
            label1.Location = new Point(32, 132);
            label1.Name = "label1";
            label1.Size = new Size(234, 18);
            label1.TabIndex = 9;
            label1.Text = "Ingresar la cantidad de trabajadores";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Khaki;
            label2.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold);
            label2.Location = new Point(21, 194);
            label2.Name = "label2";
            label2.Size = new Size(242, 18);
            label2.TabIndex = 10;
            label2.Text = "Horas trabajadas por cada trabajador";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Khaki;
            label3.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold);
            label3.Location = new Point(161, 254);
            label3.Name = "label3";
            label3.Size = new Size(105, 18);
            label3.TabIndex = 11;
            label3.Text = "Tarifa por hora";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Khaki;
            label4.Location = new Point(12, 9);
            label4.Name = "label4";
            label4.Size = new Size(137, 15);
            label4.TabIndex = 12;
            label4.Text = "Trabajadores Registrados";
            // 
            // FormEjercicio7
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(609, 354);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(btnLimpiar);
            Controls.Add(lstTrabajadores);
            Controls.Add(lblSumaTotal);
            Controls.Add(btnCalcularSuma);
            Controls.Add(btnAgregar);
            Controls.Add(txtTarifa);
            Controls.Add(txtHoras);
            Controls.Add(txtNumTrabajadores);
            Name = "FormEjercicio7";
            Text = "FormEjercicio7";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtNumTrabajadores;
        private TextBox txtHoras;
        private TextBox txtTarifa;
        private Button btnAgregar;
        private Button btnCalcularSuma;
        private Label lblSumaTotal;
        private ListBox lstTrabajadores;
        private Button btnLimpiar;
        private Button button1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
    }
}