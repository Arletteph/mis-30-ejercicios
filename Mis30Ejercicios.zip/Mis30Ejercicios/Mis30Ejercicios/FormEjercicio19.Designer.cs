﻿namespace Mis30Ejercicios
{
    partial class FormEjercicio19
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtNum1 = new TextBox();
            lblResultado = new Label();
            txtNum2 = new TextBox();
            lblContador = new Label();
            label2 = new Label();
            label3 = new Label();
            btnCalcular = new Button();
            button1 = new Button();
            btnLimpiar = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(173, 90);
            label1.Name = "label1";
            label1.Size = new Size(266, 25);
            label1.TabIndex = 0;
            label1.Text = "Calculadora con 10 Procesos";
            // 
            // txtNum1
            // 
            txtNum1.Location = new Point(235, 149);
            txtNum1.Name = "txtNum1";
            txtNum1.Size = new Size(100, 23);
            txtNum1.TabIndex = 1;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Location = new Point(368, 157);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(59, 15);
            lblResultado.TabIndex = 2;
            lblResultado.Text = "Resultado";
            // 
            // txtNum2
            // 
            txtNum2.Location = new Point(234, 189);
            txtNum2.Name = "txtNum2";
            txtNum2.Size = new Size(100, 23);
            txtNum2.TabIndex = 3;
            // 
            // lblContador
            // 
            lblContador.AutoSize = true;
            lblContador.Location = new Point(454, 157);
            lblContador.Name = "lblContador";
            lblContador.Size = new Size(83, 15);
            lblContador.TabIndex = 4;
            lblContador.Text = "Contador 0/10";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(166, 152);
            label2.Name = "label2";
            label2.Size = new Size(40, 15);
            label2.TabIndex = 5;
            label2.Text = "Num1";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(166, 197);
            label3.Name = "label3";
            label3.Size = new Size(40, 15);
            label3.TabIndex = 6;
            label3.Text = "Num2";
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(264, 255);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(75, 23);
            btnCalcular.TabIndex = 7;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // button1
            // 
            button1.Location = new Point(183, 255);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 8;
            button1.Text = "Volver";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // btnLimpiar
            // 
            btnLimpiar.Location = new Point(352, 255);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(75, 23);
            btnLimpiar.TabIndex = 9;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = true;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // FormEjercicio19
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.descarga__30_;
            ClientSize = new Size(652, 360);
            Controls.Add(btnLimpiar);
            Controls.Add(button1);
            Controls.Add(btnCalcular);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(lblContador);
            Controls.Add(txtNum2);
            Controls.Add(lblResultado);
            Controls.Add(txtNum1);
            Controls.Add(label1);
            Name = "FormEjercicio19";
            Text = "FormEjercicio19";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtNum1;
        private Label lblResultado;
        private TextBox txtNum2;
        private Label lblContador;
        private Label label2;
        private Label label3;
        private Button btnCalcular;
        private Button button1;
        private Button btnLimpiar;
    }
}