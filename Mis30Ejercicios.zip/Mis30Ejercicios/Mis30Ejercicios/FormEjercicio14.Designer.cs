﻿namespace Mis30Ejercicios
{
    partial class FormEjercicio14
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnAgregarNumeros = new Button();
            btnLimpiar = new Button();
            button1 = new Button();
            txtNumero = new TextBox();
            lblContador = new Label();
            lblResultado = new Label();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // btnAgregarNumeros
            // 
            btnAgregarNumeros.BackColor = Color.LightPink;
            btnAgregarNumeros.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold);
            btnAgregarNumeros.Location = new Point(360, 249);
            btnAgregarNumeros.Name = "btnAgregarNumeros";
            btnAgregarNumeros.Size = new Size(75, 27);
            btnAgregarNumeros.TabIndex = 0;
            btnAgregarNumeros.Text = "Agregar";
            btnAgregarNumeros.UseVisualStyleBackColor = false;
            btnAgregarNumeros.Click += btnAgregarNumeros_Click;
            // 
            // btnLimpiar
            // 
            btnLimpiar.BackColor = Color.LightPink;
            btnLimpiar.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold);
            btnLimpiar.Location = new Point(258, 249);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(75, 27);
            btnLimpiar.TabIndex = 1;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = false;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.LightPink;
            button1.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold);
            button1.Location = new Point(149, 249);
            button1.Name = "button1";
            button1.Size = new Size(75, 27);
            button1.TabIndex = 2;
            button1.Text = "Volver";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // txtNumero
            // 
            txtNumero.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold);
            txtNumero.Location = new Point(249, 184);
            txtNumero.Name = "txtNumero";
            txtNumero.Size = new Size(100, 25);
            txtNumero.TabIndex = 3;
            // 
            // lblContador
            // 
            lblContador.AutoSize = true;
            lblContador.BackColor = Color.LightPink;
            lblContador.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold);
            lblContador.Location = new Point(373, 191);
            lblContador.Name = "lblContador";
            lblContador.Size = new Size(67, 18);
            lblContador.TabIndex = 4;
            lblContador.Text = "Contador";
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.BackColor = Color.LightPink;
            lblResultado.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold);
            lblResultado.Location = new Point(373, 161);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(69, 18);
            lblResultado.TabIndex = 5;
            lblResultado.Text = "Resultado";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.LightPink;
            label1.Font = new Font("Sylfaen", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(216, 78);
            label1.Name = "label1";
            label1.Size = new Size(146, 27);
            label1.TabIndex = 6;
            label1.Text = "Contador 100";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.LightPink;
            label2.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(121, 187);
            label2.Name = "label2";
            label2.Size = new Size(122, 18);
            label2.TabIndex = 7;
            label2.Text = "Ingresa el numero";
            // 
            // FormEjercicio14
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.descarga__24_;
            ClientSize = new Size(554, 359);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(lblResultado);
            Controls.Add(lblContador);
            Controls.Add(txtNumero);
            Controls.Add(button1);
            Controls.Add(btnLimpiar);
            Controls.Add(btnAgregarNumeros);
            Name = "FormEjercicio14";
            Text = "FormEjercicio14";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnAgregarNumeros;
        private Button btnLimpiar;
        private Button button1;
        private TextBox txtNumero;
        private Label lblContador;
        private Label lblResultado;
        private Label label1;
        private Label label2;
    }
}