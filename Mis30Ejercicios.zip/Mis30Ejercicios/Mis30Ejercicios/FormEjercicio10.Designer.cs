﻿namespace Mis30Ejercicios
{
    partial class FormEjercicio10
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtNumero = new TextBox();
            btnCalcular = new Button();
            btnLimpiar = new Button();
            button1 = new Button();
            lblResultado = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Sylfaen", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(268, 79);
            label1.Name = "label1";
            label1.Size = new Size(158, 25);
            label1.TabIndex = 0;
            label1.Text = "Suma de Digitos";
            // 
            // txtNumero
            // 
            txtNumero.Location = new Point(300, 135);
            txtNumero.Name = "txtNumero";
            txtNumero.Size = new Size(100, 23);
            txtNumero.TabIndex = 1;
            // 
            // btnCalcular
            // 
            btnCalcular.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            btnCalcular.Location = new Point(297, 197);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(81, 28);
            btnCalcular.TabIndex = 2;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnLimpiar
            // 
            btnLimpiar.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            btnLimpiar.Location = new Point(403, 197);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(81, 28);
            btnLimpiar.TabIndex = 3;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = true;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // button1
            // 
            button1.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            button1.Location = new Point(197, 197);
            button1.Name = "button1";
            button1.Size = new Size(81, 28);
            button1.TabIndex = 4;
            button1.Text = "Volver";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            lblResultado.Location = new Point(442, 136);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(83, 22);
            lblResultado.TabIndex = 5;
            lblResultado.Text = "Resultado";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(164, 138);
            label2.Name = "label2";
            label2.Size = new Size(127, 18);
            label2.TabIndex = 6;
            label2.Text = "Ingresa un número";
            // 
            // FormEjercicio10
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.descarga__28_;
            ClientSize = new Size(690, 346);
            Controls.Add(label2);
            Controls.Add(lblResultado);
            Controls.Add(button1);
            Controls.Add(btnLimpiar);
            Controls.Add(btnCalcular);
            Controls.Add(txtNumero);
            Controls.Add(label1);
            Name = "FormEjercicio10";
            Text = "FormEjercicio10";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtNumero;
        private Button btnCalcular;
        private Button btnLimpiar;
        private Button button1;
        private Label lblResultado;
        private Label label2;
    }
}