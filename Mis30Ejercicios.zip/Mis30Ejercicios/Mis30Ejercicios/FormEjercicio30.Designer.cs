﻿namespace Mis30Ejercicios
{
    partial class FormEjercicio30
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormEjercicio30));
            txtClave = new TextBox();
            btnVerificar = new Button();
            lblMensaje = new Label();
            lblPista = new Label();
            btnReiniciar = new Button();
            button1 = new Button();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // txtClave
            // 
            txtClave.Location = new Point(229, 144);
            txtClave.Name = "txtClave";
            txtClave.Size = new Size(100, 23);
            txtClave.TabIndex = 0;
            // 
            // btnVerificar
            // 
            btnVerificar.BackColor = Color.Plum;
            btnVerificar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            btnVerificar.Location = new Point(341, 229);
            btnVerificar.Name = "btnVerificar";
            btnVerificar.Size = new Size(75, 30);
            btnVerificar.TabIndex = 1;
            btnVerificar.Text = "Verificar";
            btnVerificar.UseVisualStyleBackColor = false;
            btnVerificar.Click += btnVerificar_Click;
            // 
            // lblMensaje
            // 
            lblMensaje.AutoSize = true;
            lblMensaje.BackColor = Color.Transparent;
            lblMensaje.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            lblMensaje.Location = new Point(341, 127);
            lblMensaje.Name = "lblMensaje";
            lblMensaje.Size = new Size(59, 17);
            lblMensaje.TabIndex = 2;
            lblMensaje.Text = "Mensaje";
            // 
            // lblPista
            // 
            lblPista.AutoSize = true;
            lblPista.BackColor = Color.Transparent;
            lblPista.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            lblPista.Location = new Point(341, 167);
            lblPista.Name = "lblPista";
            lblPista.Size = new Size(38, 17);
            lblPista.TabIndex = 3;
            lblPista.Text = "Pista";
            // 
            // btnReiniciar
            // 
            btnReiniciar.BackColor = Color.Plum;
            btnReiniciar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            btnReiniciar.Location = new Point(254, 229);
            btnReiniciar.Name = "btnReiniciar";
            btnReiniciar.Size = new Size(75, 30);
            btnReiniciar.TabIndex = 4;
            btnReiniciar.Text = "Reiniciar";
            btnReiniciar.UseVisualStyleBackColor = false;
            btnReiniciar.Click += btnReiniciar_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Plum;
            button1.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            button1.Location = new Point(173, 229);
            button1.Name = "button1";
            button1.Size = new Size(75, 30);
            button1.TabIndex = 5;
            button1.Text = "Volver";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(202, 44);
            label1.Name = "label1";
            label1.Size = new Size(167, 25);
            label1.TabIndex = 6;
            label1.Text = "Claves para Fiesta";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(59, 145);
            label2.Name = "label2";
            label2.Size = new Size(150, 17);
            label2.TabIndex = 7;
            label2.Text = "Ingresa la clave secreta";
            // 
            // FormEjercicio30
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(569, 318);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(btnReiniciar);
            Controls.Add(lblPista);
            Controls.Add(lblMensaje);
            Controls.Add(btnVerificar);
            Controls.Add(txtClave);
            Name = "FormEjercicio30";
            Text = "FormEjercicio30";
            Load += FormEjercicio30_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtClave;
        private Button btnVerificar;
        private Label lblMensaje;
        private Label lblPista;
        private Button btnReiniciar;
        private Button button1;
        private Label label1;
        private Label label2;
    }
}