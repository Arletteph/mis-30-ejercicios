﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mis30Ejercicios
{
    public partial class FormEjercicio23 : Form
    {
        public FormEjercicio23()
        {
            InitializeComponent();
        }

        private void txtCatB_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtCatA.Text, out double catetoA) &&
                double.TryParse(txtCatB.Text, out double catetoB))
            {
                // Validar que los catetos sean positivos
                if (catetoA <= 0 || catetoB <= 0)
                {
                    lblResultado.Text = "Error: Los catetos deben ser mayores a cero.";
                   
                    return;
                }

                // Calcular hipotenusa 
                double hipotenusa = Math.Round(Math.Sqrt(Math.Pow(catetoA, 2) + Math.Pow(catetoB, 2)), 2);
                lblResultado.Text = $"Hipotenusa: {hipotenusa}";
              
            }
            else
            {
                MessageBox.Show("Ingrese valores numéricos válidos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtCatA.Clear();
            txtCatB.Clear();
            lblResultado.Text = "Resultado";
            txtCatA.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
