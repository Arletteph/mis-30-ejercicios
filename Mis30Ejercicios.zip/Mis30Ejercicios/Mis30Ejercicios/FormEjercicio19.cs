﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mis30Ejercicios
{
    public partial class FormEjercicio19 : Form
    {
        private int contadorProcesos = 0;
        private double sumaTotal = 0, restaTotal = 0, multiplicacionTotal = 1;
        public FormEjercicio19()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (contadorProcesos >= 10)
            {
                MessageBox.Show("Ya se realizaron 10 procesos.", "Fin", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (double.TryParse(txtNum1.Text, out double num1) && double.TryParse(txtNum2.Text, out double num2))
            {
                contadorProcesos++;
                lblContador.Text = $"Contador {contadorProcesos}/10";

                // Operaciones
                double suma = num1 + num2;
                double resta = num1 - num2;
                double multiplicacion = num1 * num2;
                string division;

                if (num2 != 0)
                {
                    division = Math.Round(num1 / num2, 2).ToString();
                }
                else
                {
                    division = "Error: División por cero";
                }

                // Mostrar resultados
                lblResultado.Text = $"""
            Suma: {suma}
            Resta: {resta}
            Multiplicación: {multiplicacion}
            División: {division}
            """;

                
                txtNum1.Clear();
                txtNum2.Clear();
                txtNum1.Focus();
            }
            else
            {
                MessageBox.Show("Ingrese números válidos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            contadorProcesos = 0;
            txtNum1.Clear();
            txtNum2.Clear();
            lblResultado.Text = "";
            lblContador.Text = "Contador 0/10";
            txtNum1.Focus();
        }
    }

}
