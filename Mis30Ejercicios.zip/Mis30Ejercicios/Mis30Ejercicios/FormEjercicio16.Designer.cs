﻿namespace Mis30Ejercicios
{
    partial class FormEjercicio16
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtCaracter = new TextBox();
            btnVerificar = new Button();
            lblResultado = new Label();
            lblMensaje = new Label();
            btnLimpiar = new Button();
            button1 = new Button();
            label1 = new Label();
            SuspendLayout();
            // 
            // txtCaracter
            // 
            txtCaracter.Location = new Point(150, 139);
            txtCaracter.Name = "txtCaracter";
            txtCaracter.Size = new Size(100, 23);
            txtCaracter.TabIndex = 0;
            // 
            // btnVerificar
            // 
            btnVerificar.BackColor = Color.LightPink;
            btnVerificar.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            btnVerificar.Location = new Point(416, 223);
            btnVerificar.Name = "btnVerificar";
            btnVerificar.Size = new Size(85, 28);
            btnVerificar.TabIndex = 1;
            btnVerificar.Text = "Verificar";
            btnVerificar.UseVisualStyleBackColor = false;
            btnVerificar.Click += btnVerificar_Click;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.BackColor = Color.LightPink;
            lblResultado.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            lblResultado.Location = new Point(309, 137);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(83, 22);
            lblResultado.TabIndex = 2;
            lblResultado.Text = "Resultado";
            // 
            // lblMensaje
            // 
            lblMensaje.AutoSize = true;
            lblMensaje.BackColor = Color.LightPink;
            lblMensaje.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            lblMensaje.Location = new Point(309, 176);
            lblMensaje.Name = "lblMensaje";
            lblMensaje.Size = new Size(71, 22);
            lblMensaje.TabIndex = 3;
            lblMensaje.Text = "Mensaje";
            // 
            // btnLimpiar
            // 
            btnLimpiar.BackColor = Color.LightPink;
            btnLimpiar.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            btnLimpiar.Location = new Point(295, 223);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(85, 28);
            btnLimpiar.TabIndex = 4;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = false;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.LightPink;
            button1.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            button1.Location = new Point(165, 223);
            button1.Name = "button1";
            button1.Size = new Size(85, 28);
            button1.TabIndex = 5;
            button1.Text = "Volver";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.LightPink;
            label1.Font = new Font("Sylfaen", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(216, 61);
            label1.Name = "label1";
            label1.Size = new Size(267, 27);
            label1.TabIndex = 6;
            label1.Text = "Detectar la Primera Vocal";
            // 
            // FormEjercicio16
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.spring_and_summer_girl_wallpaper;
            ClientSize = new Size(721, 373);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(btnLimpiar);
            Controls.Add(lblMensaje);
            Controls.Add(lblResultado);
            Controls.Add(btnVerificar);
            Controls.Add(txtCaracter);
            Name = "FormEjercicio16";
            Text = "FormEjercicio16";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtCaracter;
        private Button btnVerificar;
        private Label lblResultado;
        private Label lblMensaje;
        private Button btnLimpiar;
        private Button button1;
        private Label label1;
    }
}