﻿namespace Mis30Ejercicios
{
    partial class FormEjercicio24
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtRadio = new TextBox();
            btnCalcular = new Button();
            button1 = new Button();
            btnLimpiar = new Button();
            label2 = new Label();
            lblResultado = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(51, 67);
            label1.Name = "label1";
            label1.Size = new Size(322, 30);
            label1.TabIndex = 0;
            label1.Text = "Circunferencia, Área y Volumen";
            // 
            // txtRadio
            // 
            txtRadio.BackColor = Color.FloralWhite;
            txtRadio.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            txtRadio.Location = new Point(154, 123);
            txtRadio.Name = "txtRadio";
            txtRadio.Size = new Size(100, 25);
            txtRadio.TabIndex = 1;
            // 
            // btnCalcular
            // 
            btnCalcular.BackColor = Color.Khaki;
            btnCalcular.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            btnCalcular.Location = new Point(260, 207);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(75, 26);
            btnCalcular.TabIndex = 2;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = false;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Khaki;
            button1.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            button1.Location = new Point(92, 207);
            button1.Name = "button1";
            button1.Size = new Size(75, 26);
            button1.TabIndex = 3;
            button1.Text = "Volver";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // btnLimpiar
            // 
            btnLimpiar.BackColor = Color.Khaki;
            btnLimpiar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            btnLimpiar.Location = new Point(179, 207);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(75, 26);
            btnLimpiar.TabIndex = 4;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = false;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            label2.Location = new Point(51, 126);
            label2.Name = "label2";
            label2.Size = new Size(104, 17);
            label2.TabIndex = 5;
            label2.Text = "Ingresa el radio";
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.BackColor = Color.Transparent;
            lblResultado.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblResultado.Location = new Point(266, 126);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(69, 17);
            lblResultado.TabIndex = 6;
            lblResultado.Text = "Resultado";
            // 
            // FormEjercicio24
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.descarga__35_;
            ClientSize = new Size(503, 332);
            Controls.Add(lblResultado);
            Controls.Add(label2);
            Controls.Add(btnLimpiar);
            Controls.Add(button1);
            Controls.Add(btnCalcular);
            Controls.Add(txtRadio);
            Controls.Add(label1);
            Name = "FormEjercicio24";
            Text = "FormEjercicio24";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtRadio;
        private Button btnCalcular;
        private Button button1;
        private Button btnLimpiar;
        private Label label2;
        private Label lblResultado;
    }
}