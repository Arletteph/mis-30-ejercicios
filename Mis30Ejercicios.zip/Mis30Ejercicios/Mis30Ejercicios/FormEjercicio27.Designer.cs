﻿namespace Mis30Ejercicios
{
    partial class FormEjercicio27
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtEgresos = new TextBox();
            btnAgregar = new Button();
            btnLimpiar = new Button();
            Volver = new Button();
            label2 = new Label();
            lblTotalEgresos = new Label();
            lblRestoCaja = new Label();
            lstEgresos = new ListBox();
            label3 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(160, 114);
            label1.Name = "label1";
            label1.Size = new Size(197, 30);
            label1.TabIndex = 0;
            label1.Text = "Control de Egresos";
            // 
            // txtEgresos
            // 
            txtEgresos.Location = new Point(226, 185);
            txtEgresos.Name = "txtEgresos";
            txtEgresos.Size = new Size(100, 23);
            txtEgresos.TabIndex = 1;
            // 
            // btnAgregar
            // 
            btnAgregar.BackColor = Color.Khaki;
            btnAgregar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            btnAgregar.Location = new Point(333, 266);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(75, 24);
            btnAgregar.TabIndex = 2;
            btnAgregar.Text = "Agregar";
            btnAgregar.UseVisualStyleBackColor = false;
            btnAgregar.Click += btnAgregar_Click;
            // 
            // btnLimpiar
            // 
            btnLimpiar.BackColor = Color.Khaki;
            btnLimpiar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            btnLimpiar.Location = new Point(242, 264);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(75, 29);
            btnLimpiar.TabIndex = 3;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = false;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // Volver
            // 
            Volver.BackColor = Color.Khaki;
            Volver.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            Volver.Location = new Point(161, 264);
            Volver.Name = "Volver";
            Volver.Size = new Size(75, 27);
            Volver.TabIndex = 4;
            Volver.Text = "Volver";
            Volver.UseVisualStyleBackColor = false;
            Volver.Click += Volver_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Khaki;
            label2.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(107, 191);
            label2.Name = "label2";
            label2.Size = new Size(113, 17);
            label2.TabIndex = 5;
            label2.Text = "Ingresa el egreso";
            // 
            // lblTotalEgresos
            // 
            lblTotalEgresos.AutoSize = true;
            lblTotalEgresos.BackColor = Color.Khaki;
            lblTotalEgresos.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            lblTotalEgresos.Location = new Point(350, 162);
            lblTotalEgresos.Name = "lblTotalEgresos";
            lblTotalEgresos.Size = new Size(109, 17);
            lblTotalEgresos.TabIndex = 6;
            lblTotalEgresos.Text = "Total de Egresos";
            // 
            // lblRestoCaja
            // 
            lblRestoCaja.AutoSize = true;
            lblRestoCaja.BackColor = Color.Khaki;
            lblRestoCaja.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            lblRestoCaja.Location = new Point(350, 213);
            lblRestoCaja.Name = "lblRestoCaja";
            lblRestoCaja.Size = new Size(91, 17);
            lblRestoCaja.TabIndex = 7;
            lblRestoCaja.Text = "Resto de Caja";
            // 
            // lstEgresos
            // 
            lstEgresos.FormattingEnabled = true;
            lstEgresos.ItemHeight = 15;
            lstEgresos.Location = new Point(12, 59);
            lstEgresos.Name = "lstEgresos";
            lstEgresos.Size = new Size(120, 94);
            lstEgresos.TabIndex = 8;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Khaki;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(12, 41);
            label3.Name = "label3";
            label3.Size = new Size(49, 15);
            label3.TabIndex = 9;
            label3.Text = "Egresos";
            // 
            // FormEjercicio27
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.descarga__33_;
            ClientSize = new Size(581, 324);
            Controls.Add(label3);
            Controls.Add(lstEgresos);
            Controls.Add(lblRestoCaja);
            Controls.Add(lblTotalEgresos);
            Controls.Add(label2);
            Controls.Add(Volver);
            Controls.Add(btnLimpiar);
            Controls.Add(btnAgregar);
            Controls.Add(txtEgresos);
            Controls.Add(label1);
            Name = "FormEjercicio27";
            Text = "FormEjercicio27";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtEgresos;
        private Button btnAgregar;
        private Button btnLimpiar;
        private Button Volver;
        private Label label2;
        private Label lblTotalEgresos;
        private Label lblRestoCaja;
        private ListBox lstEgresos;
        private Label label3;
    }
}