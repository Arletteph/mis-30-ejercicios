﻿namespace Mis30Ejercicios
{
    partial class FormEjercicio23
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtCatA = new TextBox();
            txtCatB = new TextBox();
            btnCalcular = new Button();
            button1 = new Button();
            btnLimpiar = new Button();
            lblResultado = new Label();
            label2 = new Label();
            label3 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(301, 70);
            label1.Name = "label1";
            label1.Size = new Size(126, 30);
            label1.TabIndex = 0;
            label1.Text = "Hipotenusa";
            // 
            // txtCatA
            // 
            txtCatA.Location = new Point(265, 130);
            txtCatA.Name = "txtCatA";
            txtCatA.Size = new Size(100, 23);
            txtCatA.TabIndex = 1;
            // 
            // txtCatB
            // 
            txtCatB.Location = new Point(263, 176);
            txtCatB.Name = "txtCatB";
            txtCatB.Size = new Size(100, 23);
            txtCatB.TabIndex = 2;
            txtCatB.TextChanged += txtCatB_TextChanged;
            // 
            // btnCalcular
            // 
            btnCalcular.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            btnCalcular.Location = new Point(406, 220);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(75, 23);
            btnCalcular.TabIndex = 3;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            button1.Location = new Point(235, 220);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 4;
            button1.Text = "Volver";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // btnLimpiar
            // 
            btnLimpiar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            btnLimpiar.Location = new Point(325, 220);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(75, 23);
            btnLimpiar.TabIndex = 5;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = true;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.BackColor = Color.Transparent;
            lblResultado.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            lblResultado.Location = new Point(394, 154);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(69, 17);
            lblResultado.TabIndex = 6;
            lblResultado.Text = "Resultado";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            label2.Location = new Point(189, 136);
            label2.Name = "label2";
            label2.Size = new Size(61, 17);
            label2.TabIndex = 7;
            label2.Text = "Cateto A";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            label3.Location = new Point(189, 182);
            label3.Name = "label3";
            label3.Size = new Size(60, 17);
            label3.TabIndex = 8;
            label3.Text = "Cateto B";
            // 
            // FormEjercicio23
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.descarga__34_;
            ClientSize = new Size(703, 309);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(lblResultado);
            Controls.Add(btnLimpiar);
            Controls.Add(button1);
            Controls.Add(btnCalcular);
            Controls.Add(txtCatB);
            Controls.Add(txtCatA);
            Controls.Add(label1);
            Name = "FormEjercicio23";
            Text = "FormEjercicio23";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtCatA;
        private TextBox txtCatB;
        private Button btnCalcular;
        private Button button1;
        private Button btnLimpiar;
        private Label lblResultado;
        private Label label2;
        private Label label3;
    }
}