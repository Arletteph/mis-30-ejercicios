using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;
using System.Drawing;
using System.Runtime.ConstrainedExecution;

namespace Mis30Ejercicios
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void ejercicio01ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEjercicio01 formEjercicio01 = new FormEjercicio01();
            formEjercicio01.Show();

        }


        private void ejercicio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEjercicio02 formEjercicio02 = new FormEjercicio02();
            formEjercicio02.Show();
        }

        private void ejercicio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEjercicio03 formEjercicio03 = new FormEjercicio03();
            formEjercicio03.Show();
        }


        private void ejercicio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEjercicio04 formEjercicio04 = new FormEjercicio04();
            formEjercicio04.Show();
        }


        private void ejercicio5ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            FormEjercicio05 formEjercicio05 = new FormEjercicio05();
            formEjercicio05.Show();
        }

        private void ejercicio6ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEjercicio06 formEjercicio06 = new FormEjercicio06();
            formEjercicio06.Show();
        }

        private void ejercicio7ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEjercicio7 formEjercicio7 = new FormEjercicio7();
            formEjercicio7.Show();
        }

        private void ejercicio8ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEjercicio08 ejercicio08 = new FormEjercicio08();
            ejercicio08.Show();
        }

        private void ejercicio9ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEjercicio09 ejercicio09 = new FormEjercicio09();
            ejercicio09.Show();
        }

        private void ejercicio10ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEjercicio10 ejercicio10 = new FormEjercicio10();
            ejercicio10.Show();
        }

        private void ejercicio11ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEjercicio11 ejercicio11 = new FormEjercicio11();
            ejercicio11.Show();
        }

        private void ejercicio12ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEjercicio12 ejercicio12 = new FormEjercicio12();
            ejercicio12.Show();
        }

        private void ejercicio13ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEjercicio13 ejercicio13 = new FormEjercicio13();
            ejercicio13.Show();
        }

        private void ejercicio14ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEjercicio14 ejercicio14 = new FormEjercicio14();
            ejercicio14.Show();
        }


        private void ejercicio16ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEjercicio16 ejercicio16 = new FormEjercicio16();
            ejercicio16.Show();
        }

        private void ejercicio15ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEjercicio15 ejercicio15 = new FormEjercicio15();
            ejercicio15.Show();
        }

        private void ejercicio17ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEjercicio17 ejercicio17 = new FormEjercicio17();
            ejercicio17.Show();
        }

        private void ejercicio19ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEjercicio19 ejercicio19 = new FormEjercicio19();
            ejercicio19.Show();
        }

        private void ejercicio18ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEjercicio18 ejercicio18 = new FormEjercicio18();
            ejercicio18.Show();
        }

        private void ejercicio20ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEjercicio20 ejercicio20 = new FormEjercicio20();
            ejercicio20.Show();
        }

        private void ejercicio21ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEjercicio21 ejercicio21 = new FormEjercicio21();
            ejercicio21.Show();
        }

        private void ejercicio22ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEjercicio22 ejercicio22 = new FormEjercicio22();
            ejercicio22.Show();
        }

        private void ejercicio23ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEjercicio23 ejercicio23 = new FormEjercicio23();
            ejercicio23.Show();
        }

        private void ejercicio24ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEjercicio24 ejercicio24 = new FormEjercicio24();
            ejercicio24.Show();
        }

        private void ejercicio25ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEjercicio25 ejercicio25 = new FormEjercicio25();
            ejercicio25.Show();
        }

        private void ejercicio26ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEjercicio26 ejercicio26 = new FormEjercicio26();
            ejercicio26.Show();
        }

        private void ejercicio27ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEjercicio27 ejercicio27 = new FormEjercicio27();
            ejercicio27.Show();
        }

        private void ejercicio28ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEjercicio28 ejercicio28 = new FormEjercicio28();
            ejercicio28.Show();
        }

        private void ejercicio29ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEjercicio29 ejercicio29 = new FormEjercicio29();
            ejercicio29.Show();
        }

        private void ejercicio30ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEjercicio30 ejercicio30 = new FormEjercicio30();
            ejercicio30.Show();
        }
    }
}
