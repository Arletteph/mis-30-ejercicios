﻿namespace Mis30Ejercicios
{
    partial class FormEjercicio13
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtNumero = new TextBox();
            btnCalcular = new Button();
            lblResultado = new Label();
            btnLimpiar = new Button();
            button1 = new Button();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // txtNumero
            // 
            txtNumero.Location = new Point(292, 134);
            txtNumero.Name = "txtNumero";
            txtNumero.Size = new Size(100, 23);
            txtNumero.TabIndex = 0;
            // 
            // btnCalcular
            // 
            btnCalcular.BackColor = Color.Pink;
            btnCalcular.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            btnCalcular.Location = new Point(386, 246);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(81, 30);
            btnCalcular.TabIndex = 1;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = false;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.BackColor = Color.Pink;
            lblResultado.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold);
            lblResultado.Location = new Point(420, 139);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(69, 18);
            lblResultado.TabIndex = 2;
            lblResultado.Text = "Resultado";
            // 
            // btnLimpiar
            // 
            btnLimpiar.BackColor = Color.Pink;
            btnLimpiar.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            btnLimpiar.Location = new Point(281, 246);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(81, 30);
            btnLimpiar.TabIndex = 3;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = false;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Pink;
            button1.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            button1.Location = new Point(167, 246);
            button1.Name = "button1";
            button1.Size = new Size(81, 30);
            button1.TabIndex = 4;
            button1.Text = "Volver";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Pink;
            label1.Font = new Font("Sylfaen", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(216, 64);
            label1.Name = "label1";
            label1.Size = new Size(208, 27);
            label1.TabIndex = 5;
            label1.Text = "Calcular el factorial";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Pink;
            label2.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold);
            label2.Location = new Point(139, 139);
            label2.Name = "label2";
            label2.Size = new Size(122, 18);
            label2.TabIndex = 6;
            label2.Text = "Ingresa el número";
            // 
            // FormEjercicio13
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.ejercicio1;
            ClientSize = new Size(684, 371);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(btnLimpiar);
            Controls.Add(lblResultado);
            Controls.Add(btnCalcular);
            Controls.Add(txtNumero);
            Name = "FormEjercicio13";
            Text = "FormEjercicio13";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtNumero;
        private Button btnCalcular;
        private Label lblResultado;
        private Button btnLimpiar;
        private Button button1;
        private Label label1;
        private Label label2;
    }
}