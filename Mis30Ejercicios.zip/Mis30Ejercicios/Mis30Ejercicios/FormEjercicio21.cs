﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mis30Ejercicios
{
    public partial class FormEjercicio21 : Form
    {
        private bool procesoFinalizado = false; 
        public FormEjercicio21()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {  if (procesoFinalizado)
            {
                MessageBox.Show("El proceso ya finalizó. Haz clic en 'Limpiar' para reiniciar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!double.TryParse(txtNum1.Text, out double num1))
            {
                MessageBox.Show("Ingrese un número válido en el primer campo.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (num1 == 0)
            {
                procesoFinalizado = true; // Marca el proceso como finalizado
                btnCalcular.Enabled = false; // Desactiva el botón
                lblResultados.Text = "PROCESO FINALIZADO (Primer número = 0).\nHaz clic en 'Limpiar' para reiniciar.";
                return;
            }

            if (!double.TryParse(txtNum2.Text, out double num2))
            {
                MessageBox.Show("Ingrese un número válido en el segundo campo.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Operaciones (suma, resta, etc.)
            double suma = num1 + num2;
            double resta = num1 - num2;
            double multiplicacion = num1 * num2;
            string division = (num2 != 0) ? Math.Round(num1 / num2, 2).ToString() : "Error: División por cero";

            lblResultados.Text = $"""
        Suma: {suma}
        Resta: {resta}
        Multiplicación: {multiplicacion}
        División: {division}
        """;

            txtNum1.Clear();
            txtNum2.Clear();
            txtNum1.Focus();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            procesoFinalizado = false; 
            btnCalcular.Enabled = true; 
            txtNum1.Clear();
            txtNum2.Clear();
            lblResultados.Text = "Resultado";
            txtNum1.Focus();
        }
    }
    

}
