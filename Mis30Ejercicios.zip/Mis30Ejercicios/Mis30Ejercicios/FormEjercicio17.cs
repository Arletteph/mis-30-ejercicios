﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mis30Ejercicios
{
    public partial class FormEjercicio17 : Form
    {
        public FormEjercicio17()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNumero.Text, out double numero))
            {
                double parteEntera = Math.Truncate(numero);

                if (numero == parteEntera)
                {
                    lblResultado.Text = "No tiene .";
                    
                }
                else
                {
                    lblResultado.Text = "Si tiene .";
                    lblResultado.ForeColor = Color.Red;
                }
            }
            else
            {
                MessageBox.Show("Ingrese un número válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtNumero.Clear();
            lblResultado.Text = "Resultado";
            txtNumero.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

}
