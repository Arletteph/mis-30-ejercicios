﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mis30Ejercicios
{
    public partial class FormEjercicio08 : Form
    {
        public FormEjercicio08()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(txtHoras.Text) || string.IsNullOrWhiteSpace(txtTarifa.Text))
            {
                MessageBox.Show("Por favor, ingrese las horas y la tarifa.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            if (double.TryParse(txtHoras.Text, out double horas) && double.TryParse(txtTarifa.Text, out double tarifa))
            {
                // Calcular el salario
                double salario = horas * tarifa;


                lblResultado.Text = $"Resultado: {salario:C}";
            }
            else
            {
                MessageBox.Show("¡Debe ingresar números válidos!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            // Limpiar TextBox
            txtHoras.Clear();
            txtTarifa.Clear();
            lblResultado.Text = "Resultado: ";
            txtHoras.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

      
    }

}
