﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mis30Ejercicios
{
    
    public partial class FormEjercicio29 : Form
    {
        private int contadorPersonas = 0;
        private int voley = 0, futbol = 0, basquet = 0, ajedrez = 0;
 
        public FormEjercicio29()
        {
            InitializeComponent();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (contadorPersonas >= 400)
            {
                MessageBox.Show("Se han registrado todas las 400 personas.", "Fin", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string deporte = txtDeporte.Text.Trim().ToLower(); 

            switch (deporte)
            {
                case "voley":
                    voley++;
                    lstDeportes.Items.Add($"{contadorPersonas + 1}. Vóley"); 
                    break;
                case "futbol":
                    futbol++;
                    lstDeportes.Items.Add($"{contadorPersonas + 1}. Fútbol");
                    break;
                case "basquet":
                    basquet++;
                    lstDeportes.Items.Add($"{contadorPersonas + 1}. Básquet");
                    break;
                case "ajedrez":
                    ajedrez++;
                    lstDeportes.Items.Add($"{contadorPersonas + 1}. Ajedrez");
                    break;
                default:
                    MessageBox.Show("Error: Deporte no válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
            }

            contadorPersonas++;
            txtDeporte.Clear();
            txtDeporte.Focus();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            contadorPersonas = 0;
            voley = futbol = basquet = ajedrez = 0;
            txtDeporte.Clear();
            lstDeportes.Items.Clear();
            txtDeporte.Focus();
        }
    }

}
