﻿namespace Mis30Ejercicios
{
    partial class FormEjercicio01
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelhoras = new Label();
            labeltarifa = new Label();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // labelhoras
            // 
            labelhoras.AutoSize = true;
            labelhoras.BackColor = Color.Transparent;
            labelhoras.Font = new Font("Sylfaen", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelhoras.Location = new Point(191, 121);
            labelhoras.Name = "labelhoras";
            labelhoras.Size = new Size(135, 22);
            labelhoras.TabIndex = 0;
            labelhoras.Text = "Ingrese las horas";
            // 
            // labeltarifa
            // 
            labeltarifa.AutoSize = true;
            labeltarifa.BackColor = Color.Transparent;
            labeltarifa.Font = new Font("Sylfaen", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labeltarifa.Location = new Point(430, 121);
            labeltarifa.Name = "labeltarifa";
            labeltarifa.Size = new Size(129, 22);
            labeltarifa.TabIndex = 1;
            labeltarifa.Text = "Ingrese la tarifa";
            // 
            // button1
            // 
            button1.BackColor = Color.LightCoral;
            button1.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            button1.ForeColor = SystemColors.GradientInactiveCaption;
            button1.Location = new Point(336, 272);
            button1.Name = "button1";
            button1.Size = new Size(83, 35);
            button1.TabIndex = 2;
            button1.Text = "Calcular";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.LightCoral;
            button2.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            button2.ForeColor = SystemColors.GradientInactiveCaption;
            button2.Location = new Point(199, 272);
            button2.Name = "button2";
            button2.Size = new Size(83, 35);
            button2.TabIndex = 3;
            button2.Text = "Volver";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.LightCoral;
            button3.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            button3.ForeColor = SystemColors.GradientInactiveCaption;
            button3.Location = new Point(465, 272);
            button3.Name = "button3";
            button3.Size = new Size(83, 35);
            button3.TabIndex = 4;
            button3.Text = "Limpiar";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(202, 183);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 5;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(448, 183);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(100, 23);
            textBox2.TabIndex = 6;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Sylfaen", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(609, 183);
            label1.Name = "label1";
            label1.Size = new Size(82, 22);
            label1.TabIndex = 7;
            label1.Text = "Salario: $";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.BorderStyle = BorderStyle.FixedSingle;
            label2.Font = new Font("Sylfaen", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(272, 66);
            label2.Name = "label2";
            label2.Size = new Size(223, 27);
            label2.TabIndex = 8;
            label2.Text = "Calculadora de Nómina";
            // 
            // FormEjercicio01
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.ejercicio1;
            ClientSize = new Size(764, 409);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(labeltarifa);
            Controls.Add(labelhoras);
            Name = "FormEjercicio01";
            Text = "FormEjercicio01";
            Load += FormEjercicio01_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelhoras;
        private Label labeltarifa;
        private Button button1;
        private Button button2;
        private Button button3;
        private TextBox textBox1;
        private TextBox textBox2;
        private Label label1;
        private Label label2;
    }
}