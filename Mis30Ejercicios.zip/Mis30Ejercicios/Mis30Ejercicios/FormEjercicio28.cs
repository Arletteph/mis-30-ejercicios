﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mis30Ejercicios
{
    public partial class FormEjercicio28 : Form
    {
        public FormEjercicio28()
        {
            InitializeComponent();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtNota1.Clear();
            txtNota2.Clear();
            lblPromedio.Text = "Promedio";
            lblComentario.Text = "Resultado";
            txtNota1.Focus();
        }

        private void Volver_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCacular_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNota1.Text, out double nota1) &&
                double.TryParse(txtNota2.Text, out double nota2))
            {
                // Validar rango de notas (0-20)
                if (nota1 < 0 || nota1 > 20 || nota2 < 0 || nota2 > 20)
                {
                    lblPromedio.Text = "Error: Las notas deben estar entre 0 y 20.";
                   
                    lblComentario.Text = "";
                    return;
                }

                // Calcular promedio
                double promedio = (nota1 + nota2) / 2;
                lblPromedio.Text = $"Promedio: {promedio:F2}";
               

                // Determinar aprobación
                if (promedio >= 10.5)
                {
                    lblComentario.Text = "Aprobado, ¡¡sigue asi!!";
                   
                }
                else
                {
                    lblComentario.Text = "Reprobado, no sigas asi🙏";
                  
                }
            }
            else
            {
                MessageBox.Show("Ingrese valores numéricos válidos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
    
}
