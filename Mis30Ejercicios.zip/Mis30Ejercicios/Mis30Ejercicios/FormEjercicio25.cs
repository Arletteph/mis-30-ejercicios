﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mis30Ejercicios
{
    public partial class FormEjercicio25 : Form
    {
        private double totalPagos = 0;
        private int contadorConsumos = 0;
        private List<double> listaConsumos = new List<double>();
        public FormEjercicio25()
        {
            InitializeComponent();
        }

 

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (contadorConsumos >= 130)
            {
                MessageBox.Show("Ya se ingresaron los 130 consumos.", "Fin", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (double.TryParse(txtConsumo.Text, out double consumo) && consumo > 0)
            {
                contadorConsumos++;
                lblContador.Text = $"Consumo {contadorConsumos}/130";

                // Aplicar descuento del 15% si el consumo > $130
                double descuento = (consumo > 130) ? consumo * 0.15 : 0;
                double consumoConDescuento = consumo - descuento;

                totalPagos += consumoConDescuento;
                listaConsumos.Add(consumoConDescuento); 

                
                lstConsumos.Items.Add($"${consumo} → ${consumoConDescuento} (Descuento: ${descuento})");

                lblTotal.Text = $"Total acumulado: ${totalPagos:F2}";
                txtConsumo.Clear();
                txtConsumo.Focus();
            }
            else
            {
                MessageBox.Show("Ingrese un valor numérico válido mayor a cero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (contadorConsumos < 130)
            {
                MessageBox.Show($"Faltan {130 - contadorConsumos} consumos por ingresar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            MessageBox.Show($"Total: ${totalPagos:F2}\nFIN DEL PROCESO", "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            totalPagos = 0;
            contadorConsumos = 0;
            listaConsumos.Clear();
            lstConsumos.Items.Clear();
            lblTotal.Text = "Total: $0.00";
            lblContador.Text = "Consumo 0/130";
            txtConsumo.Clear();
            txtConsumo.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

}
