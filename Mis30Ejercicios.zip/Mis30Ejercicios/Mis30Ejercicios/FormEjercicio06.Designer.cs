﻿namespace Mis30Ejercicios
{
    partial class FormEjercicio06
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtNumero = new TextBox();
            btnCalcular = new Button();
            btnLimpiar = new Button();
            button3 = new Button();
            Serie = new ListBox();
            lblResultado = new Label();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // txtNumero
            // 
            txtNumero.Location = new Point(316, 178);
            txtNumero.Name = "txtNumero";
            txtNumero.Size = new Size(100, 23);
            txtNumero.TabIndex = 0;
            // 
            // btnCalcular
            // 
            btnCalcular.BackColor = Color.Pink;
            btnCalcular.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            btnCalcular.Location = new Point(331, 253);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(81, 35);
            btnCalcular.TabIndex = 1;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = false;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnLimpiar
            // 
            btnLimpiar.BackColor = Color.Pink;
            btnLimpiar.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            btnLimpiar.Location = new Point(432, 253);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(81, 35);
            btnLimpiar.TabIndex = 2;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = false;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.Pink;
            button3.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            button3.Location = new Point(223, 253);
            button3.Name = "button3";
            button3.Size = new Size(81, 35);
            button3.TabIndex = 3;
            button3.Text = "Volver";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // Serie
            // 
            Serie.BackColor = Color.Pink;
            Serie.FormattingEnabled = true;
            Serie.ItemHeight = 15;
            Serie.Location = new Point(45, 107);
            Serie.Name = "Serie";
            Serie.Size = new Size(120, 94);
            Serie.TabIndex = 4;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.BackColor = Color.Pink;
            lblResultado.BorderStyle = BorderStyle.FixedSingle;
            lblResultado.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblResultado.Location = new Point(453, 181);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(71, 20);
            lblResultado.TabIndex = 5;
            lblResultado.Text = "Resultado";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Sylfaen", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(192, 183);
            label1.Name = "label1";
            label1.Size = new Size(112, 16);
            label1.TabIndex = 6;
            label1.Text = "Ingresa el numero";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Pink;
            label2.Font = new Font("Sylfaen", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(274, 107);
            label2.Name = "label2";
            label2.Size = new Size(180, 25);
            label2.TabIndex = 7;
            label2.Text = "Suma Acumulativa";
            // 
            // FormEjercicio06
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.ejercicio1;
            ClientSize = new Size(754, 405);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(lblResultado);
            Controls.Add(Serie);
            Controls.Add(button3);
            Controls.Add(btnLimpiar);
            Controls.Add(btnCalcular);
            Controls.Add(txtNumero);
            Name = "FormEjercicio06";
            Text = "FormEjercicio06";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtNumero;
        private Button btnCalcular;
        private Button btnLimpiar;
        private Button button3;
        private ListBox Serie;
        private Label lblResultado;
        private Label label1;
        private Label label2;
    }
}