﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mis30Ejercicios
{
    public partial class FormEjercicio26 : Form
    {
        public FormEjercicio26()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtNumeroN.Text, out int numeroN))
            {
                if (numeroN < 8)
                {
                    lblResultado.Text = "Error: El número debe ser mayor o igual a 8.";
                 
                    return;
                }

                int suma = 0;
                for (int x = 8; x <= numeroN; x++)
                {
                    suma += x;
                }

                lblResultado.Text = $"La suma de (8 hasta {numeroN}) es: {suma}";
              
            }
            else
            {
                MessageBox.Show("Ingrese un número entero válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtNumeroN.Clear();
            lblResultado.Text = "Resultado";
            txtNumeroN.Focus();
        }
    }

}
