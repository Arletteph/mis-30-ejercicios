﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mis30Ejercicios
{
    public partial class FormEjercicio01 : Form
    {
        public FormEjercicio01()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textBox1.Text, out double horas) &&
       double.TryParse(textBox2.Text, out double tarifa))
            {
                double salario;
                if (horas <= 40 && horas >= 0)
                {
                    salario = horas * tarifa;
                }
                else if (horas > 40)
                {
                    double horasExtra = horas - 40;
                    double tarifaExtra = tarifa * 1.5;
                    salario = (40 * tarifa) + (horasExtra * tarifaExtra);
                }
                else
                {
                    label1.Text = "Error: Horas no válidas";
                    return;
                }
                label1.Text = $"Salario: ${salario:F2}";
            }
            else
            {
                MessageBox.Show("Ingresa números válidos.", "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FormEjercicio01_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            labelhoras.Text = "Salario: $0.00";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
