﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mis30Ejercicios
{
    public partial class FormEjercicio20 : Form
    {
        public FormEjercicio20()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNumero.Text, out double numero))
            {
                if (numero == 0)
                {
                    MessageBox.Show("Proceso finalizado (se ingresó 0).", "Fin", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }


                double cubo = Math.Pow(numero, 3);
                string raizCuadrada;

                if (numero >= 0)
                {
                    raizCuadrada = Math.Round(Math.Sqrt(numero), 2).ToString();
                }
                else
                {
                    raizCuadrada = $"{Math.Round(Math.Sqrt(-numero), 2)}i (imaginaria)";
                }

                lblResultado.Text = $"""
            Número: {numero}
            Cubo: {cubo}
            Raíz cuadrada: {raizCuadrada}
            """;

                txtNumero.Clear();
                txtNumero.Focus();
            }
            else
            {
                MessageBox.Show("Ingrese un número válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtNumero.Clear();
            lblResultado.Text = "Resultado";
            txtNumero.Focus();
        }
    }


   }


