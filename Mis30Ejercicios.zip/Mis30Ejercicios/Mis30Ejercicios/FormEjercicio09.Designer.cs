﻿namespace Mis30Ejercicios
{
    partial class FormEjercicio09
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtNotas = new TextBox();
            btnAgregarNota = new Button();
            btnCalcular = new Button();
            btnLimpiar = new Button();
            volver = new Button();
            lstNotas = new ListBox();
            lblAprobadas = new Label();
            lblDesaprobadas = new Label();
            lblPromedioGeneral = new Label();
            lblPromedioAprobadas = new Label();
            lblPromedioreprobadas = new Label();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            SuspendLayout();
            // 
            // txtNotas
            // 
            txtNotas.Location = new Point(244, 142);
            txtNotas.Name = "txtNotas";
            txtNotas.Size = new Size(135, 23);
            txtNotas.TabIndex = 0;
            // 
            // btnAgregarNota
            // 
            btnAgregarNota.BackColor = Color.IndianRed;
            btnAgregarNota.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            btnAgregarNota.Location = new Point(385, 137);
            btnAgregarNota.Name = "btnAgregarNota";
            btnAgregarNota.Size = new Size(133, 29);
            btnAgregarNota.TabIndex = 1;
            btnAgregarNota.Text = "Agregar Notas";
            btnAgregarNota.UseVisualStyleBackColor = false;
            btnAgregarNota.Click += btnAgregarNota_Click;
            // 
            // btnCalcular
            // 
            btnCalcular.BackColor = Color.IndianRed;
            btnCalcular.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            btnCalcular.Location = new Point(537, 137);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(83, 29);
            btnCalcular.TabIndex = 2;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = false;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnLimpiar
            // 
            btnLimpiar.BackColor = Color.IndianRed;
            btnLimpiar.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            btnLimpiar.Location = new Point(537, 172);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(83, 29);
            btnLimpiar.TabIndex = 3;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = false;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // volver
            // 
            volver.BackColor = Color.IndianRed;
            volver.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            volver.Location = new Point(385, 172);
            volver.Name = "volver";
            volver.Size = new Size(83, 29);
            volver.TabIndex = 4;
            volver.Text = "Volver";
            volver.UseVisualStyleBackColor = false;
            volver.Click += volver_Click;
            // 
            // lstNotas
            // 
            lstNotas.BackColor = Color.IndianRed;
            lstNotas.FormattingEnabled = true;
            lstNotas.ItemHeight = 15;
            lstNotas.Location = new Point(434, 253);
            lstNotas.Name = "lstNotas";
            lstNotas.Size = new Size(186, 124);
            lstNotas.TabIndex = 5;
            // 
            // lblAprobadas
            // 
            lblAprobadas.AutoSize = true;
            lblAprobadas.BackColor = Color.IndianRed;
            lblAprobadas.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold);
            lblAprobadas.Location = new Point(21, 237);
            lblAprobadas.Name = "lblAprobadas";
            lblAprobadas.Size = new Size(75, 18);
            lblAprobadas.TabIndex = 6;
            lblAprobadas.Text = "Aprobadas";
            // 
            // lblDesaprobadas
            // 
            lblDesaprobadas.AutoSize = true;
            lblDesaprobadas.BackColor = Color.IndianRed;
            lblDesaprobadas.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold);
            lblDesaprobadas.Location = new Point(145, 237);
            lblDesaprobadas.Name = "lblDesaprobadas";
            lblDesaprobadas.Size = new Size(81, 18);
            lblDesaprobadas.TabIndex = 7;
            lblDesaprobadas.Text = "Reprobadas";
            // 
            // lblPromedioGeneral
            // 
            lblPromedioGeneral.AutoSize = true;
            lblPromedioGeneral.BackColor = Color.IndianRed;
            lblPromedioGeneral.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold);
            lblPromedioGeneral.Location = new Point(21, 292);
            lblPromedioGeneral.Name = "lblPromedioGeneral";
            lblPromedioGeneral.Size = new Size(123, 18);
            lblPromedioGeneral.TabIndex = 8;
            lblPromedioGeneral.Text = "Promedio General";
            // 
            // lblPromedioAprobadas
            // 
            lblPromedioAprobadas.AutoSize = true;
            lblPromedioAprobadas.BackColor = Color.IndianRed;
            lblPromedioAprobadas.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold);
            lblPromedioAprobadas.Location = new Point(166, 292);
            lblPromedioAprobadas.Name = "lblPromedioAprobadas";
            lblPromedioAprobadas.Size = new Size(160, 18);
            lblPromedioAprobadas.TabIndex = 9;
            lblPromedioAprobadas.Text = "Promedio de Aprobadas";
            // 
            // lblPromedioreprobadas
            // 
            lblPromedioreprobadas.AutoSize = true;
            lblPromedioreprobadas.BackColor = Color.IndianRed;
            lblPromedioreprobadas.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold);
            lblPromedioreprobadas.Location = new Point(19, 349);
            lblPromedioreprobadas.Name = "lblPromedioreprobadas";
            lblPromedioreprobadas.Size = new Size(179, 18);
            lblPromedioreprobadas.TabIndex = 10;
            lblPromedioreprobadas.Text = "Promedio de Desaprobadas";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(434, 232);
            label1.Name = "label1";
            label1.Size = new Size(44, 18);
            label1.TabIndex = 11;
            label1.Text = "Notas";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.IndianRed;
            label2.Font = new Font("Sylfaen", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(220, 70);
            label2.Name = "label2";
            label2.Size = new Size(197, 25);
            label2.TabIndex = 12;
            label2.Text = "Estadisticas de Notas";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(99, 142);
            label3.Name = "label3";
            label3.Size = new Size(105, 18);
            label3.TabIndex = 13;
            label3.Text = "Ingrese la nota:";
            // 
            // FormEjercicio09
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.descarga__27_;
            ClientSize = new Size(673, 416);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(lblPromedioreprobadas);
            Controls.Add(lblPromedioAprobadas);
            Controls.Add(lblPromedioGeneral);
            Controls.Add(lblDesaprobadas);
            Controls.Add(lblAprobadas);
            Controls.Add(lstNotas);
            Controls.Add(volver);
            Controls.Add(btnLimpiar);
            Controls.Add(btnCalcular);
            Controls.Add(btnAgregarNota);
            Controls.Add(txtNotas);
            Name = "FormEjercicio09";
            Text = "FormEjercicio09";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtNotas;
        private Button btnAgregarNota;
        private Button btnCalcular;
        private Button btnLimpiar;
        private Button volver;
        private ListBox lstNotas;
        private Label lblAprobadas;
        private Label lblDesaprobadas;
        private Label lblPromedioGeneral;
        private Label lblPromedioAprobadas;
        private Label lblPromedioreprobadas;
        private Label label1;
        private Label label2;
        private Label label3;
    }
}