﻿namespace Mis30Ejercicios
{
    partial class FormEjercicio17
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtNumero = new TextBox();
            btnVerificar = new Button();
            lblResultado = new Label();
            btnLimpiar = new Button();
            button1 = new Button();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // txtNumero
            // 
            txtNumero.Location = new Point(193, 109);
            txtNumero.Name = "txtNumero";
            txtNumero.Size = new Size(100, 23);
            txtNumero.TabIndex = 0;
            // 
            // btnVerificar
            // 
            btnVerificar.BackColor = Color.Transparent;
            btnVerificar.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            btnVerificar.Location = new Point(296, 167);
            btnVerificar.Name = "btnVerificar";
            btnVerificar.Size = new Size(86, 29);
            btnVerificar.TabIndex = 1;
            btnVerificar.Text = "Verificar";
            btnVerificar.UseVisualStyleBackColor = false;
            btnVerificar.Click += btnVerificar_Click;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.BackColor = Color.Black;
            lblResultado.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold);
            lblResultado.ForeColor = SystemColors.ButtonHighlight;
            lblResultado.Location = new Point(313, 114);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(69, 18);
            lblResultado.TabIndex = 2;
            lblResultado.Text = "Resultado";
            // 
            // btnLimpiar
            // 
            btnLimpiar.BackColor = Color.Transparent;
            btnLimpiar.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            btnLimpiar.Location = new Point(193, 167);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(86, 29);
            btnLimpiar.TabIndex = 3;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = false;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Transparent;
            button1.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            button1.Location = new Point(81, 167);
            button1.Name = "button1";
            button1.Size = new Size(86, 29);
            button1.TabIndex = 4;
            button1.Text = "Volver";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(163, 46);
            label1.Name = "label1";
            label1.Size = new Size(173, 25);
            label1.TabIndex = 5;
            label1.Text = "Parte Fraccionaria";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Black;
            label2.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold);
            label2.ForeColor = SystemColors.ButtonHighlight;
            label2.Location = new Point(65, 110);
            label2.Name = "label2";
            label2.Size = new Size(122, 18);
            label2.TabIndex = 6;
            label2.Text = "Ingresa el número";
            // 
            // FormEjercicio17
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.descarga__31_;
            ClientSize = new Size(476, 341);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(btnLimpiar);
            Controls.Add(lblResultado);
            Controls.Add(btnVerificar);
            Controls.Add(txtNumero);
            Name = "FormEjercicio17";
            Text = "FormEjercicio17";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtNumero;
        private Button btnVerificar;
        private Label lblResultado;
        private Button btnLimpiar;
        private Button button1;
        private Label label1;
        private Label label2;
    }
}