﻿namespace Mis30Ejercicios
{
    partial class FormEjercicio18
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtCoefA = new TextBox();
            txtCoefB = new TextBox();
            txtCoefC = new TextBox();
            btnLimpiar = new Button();
            btnCalcular = new Button();
            button1 = new Button();
            lblResultado = new Label();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            SuspendLayout();
            // 
            // txtCoefA
            // 
            txtCoefA.Location = new Point(201, 117);
            txtCoefA.Name = "txtCoefA";
            txtCoefA.Size = new Size(100, 23);
            txtCoefA.TabIndex = 0;
            // 
            // txtCoefB
            // 
            txtCoefB.Location = new Point(201, 160);
            txtCoefB.Name = "txtCoefB";
            txtCoefB.Size = new Size(100, 23);
            txtCoefB.TabIndex = 1;
            // 
            // txtCoefC
            // 
            txtCoefC.Location = new Point(201, 199);
            txtCoefC.Name = "txtCoefC";
            txtCoefC.Size = new Size(100, 23);
            txtCoefC.TabIndex = 2;
            // 
            // btnLimpiar
            // 
            btnLimpiar.Location = new Point(199, 253);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(75, 23);
            btnLimpiar.TabIndex = 3;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = true;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(290, 253);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(75, 23);
            btnCalcular.TabIndex = 4;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // button1
            // 
            button1.Location = new Point(114, 252);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 5;
            button1.Text = "Volver";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Location = new Point(343, 160);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(59, 15);
            lblResultado.TabIndex = 6;
            lblResultado.Text = "Resultado";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(60, 120);
            label1.Name = "label1";
            label1.Size = new Size(129, 15);
            label1.TabIndex = 7;
            label1.Text = "Ingresa el coeficiente A";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(60, 168);
            label2.Name = "label2";
            label2.Size = new Size(128, 15);
            label2.TabIndex = 8;
            label2.Text = "Ingresa el coeficiente B";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(59, 207);
            label3.Name = "label3";
            label3.Size = new Size(129, 15);
            label3.TabIndex = 9;
            label3.Text = "Ingresa el coeficiente C";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(114, 54);
            label4.Name = "label4";
            label4.Size = new Size(189, 25);
            label4.TabIndex = 10;
            label4.Text = " Ecuación Cuadrática";
            // 
            // FormEjercicio18
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.spring_and_summer_girl_wallpaper;
            ClientSize = new Size(495, 308);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(lblResultado);
            Controls.Add(button1);
            Controls.Add(btnCalcular);
            Controls.Add(btnLimpiar);
            Controls.Add(txtCoefC);
            Controls.Add(txtCoefB);
            Controls.Add(txtCoefA);
            Name = "FormEjercicio18";
            Text = "FormEjercicio18";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtCoefA;
        private TextBox txtCoefB;
        private TextBox txtCoefC;
        private Button btnLimpiar;
        private Button btnCalcular;
        private Button button1;
        private Label lblResultado;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
    }
}