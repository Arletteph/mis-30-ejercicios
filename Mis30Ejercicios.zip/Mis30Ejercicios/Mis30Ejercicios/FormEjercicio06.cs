﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mis30Ejercicios
{
    public partial class FormEjercicio06 : Form
    {
        public FormEjercicio06()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtNumero.Text, out int numero) && numero > 0)
            {
                Serie.Items.Clear();
                int suma = 0;

                for (int x = 1; x <= numero; x++)
                {
                    suma += x;
                    Serie.Items.Add($" {x}"); ;
                }

                lblResultado.Text = $"Suma total: {suma}";
            }
            else
            {
                MessageBox.Show("Ingrese un número entero positivo.", "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtNumero.Clear();
            Serie.Items.Clear();
            lblResultado.Text = "Resultado:";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       
    }
}
