﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mis30Ejercicios
{
    public partial class FormEjercicio10 : Form
    {
        private int sumaDigitos = 0;
        public FormEjercicio10()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(txtNumero.Text))
            {
                MessageBox.Show("Por favor ingrese un número.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validar que sea un número entero
            if (int.TryParse(txtNumero.Text, out int numero))
            {
                sumaDigitos = 0;
                int numeroAbsoluto = Math.Abs(numero);

                // Calcular suma de dígitos
                while (numeroAbsoluto > 0)
                {
                    int digito = numeroAbsoluto % 10;
                    sumaDigitos += digito;
                    numeroAbsoluto /= 10;
                }


                lblResultado.Text = $"La suma de los dígitos es: {sumaDigitos}";
            }
            else
            {
                MessageBox.Show("Ingrese un número válido (sin decimales).", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {

            txtNumero.Clear();
            lblResultado.Text = "";
            sumaDigitos = 0;
            txtNumero.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }


}
