﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mis30Ejercicios
{
    public partial class FormEjercicio13 : Form
    {
        public FormEjercicio13()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtNumero.Text, out int numero) && numero >= 0)
            {
                long factorial = 1;

                for (int i = 1; i <= numero; i++)
                {
                    factorial *= i;
                }

                lblResultado.Text = $"{numero}! = {factorial}";
            }
            else
            {
                MessageBox.Show("Ingrese un número entero positivo válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtNumero.Clear();
            lblResultado.Text = "Resultado";
            txtNumero.Focus(); 
        }
    }
}
