﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mis30Ejercicios
{
    public partial class FormEjercicio12 : Form
    {
        private List<int> numeros = new List<int>();
        private int pares = 0, impares = 0, positivos = 0, negativos = 0;
        public FormEjercicio12()
        {
            InitializeComponent();
        }

        private void lblPositivos_Click(object sender, EventArgs e)
        {

        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtNumero.Text, out int numero))
            {
                numeros.Add(numero);
                lstNumeros.Items.Add(numero); // Mostrar en ListBox

                // Clasificar el número
                if (numero % 2 == 0) pares++; else impares++;
                if (numero > 0) positivos++; else if (numero < 0) negativos++; // Ojo: el 0 no cuenta

                txtNumero.Clear(); // Limpiar el TextBox
                txtNumero.Focus(); // Regresar el foco
            }
            else
            {
                MessageBox.Show("Ingrese un número válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (numeros.Count == 0)
            {
                MessageBox.Show("Ingrese al menos un número.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Mostrar resultados en Labels
            lblPares.Text = $"Pares: {pares}";
            lblImpares.Text = $"Impares: {impares}";
            lblPositivos.Text = $"Positivos: {positivos}";
            lblNegativos.Text = $"Negativos: {negativos}";
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            numeros.Clear();
            lstNumeros.Items.Clear();
            pares = impares = positivos = negativos = 0;
            lblPares.Text = "Pares: 0";
            lblImpares.Text = "Impares: 0";
            lblPositivos.Text = "Positivos: 0";
            lblNegativos.Text = "Negativos: 0";

            txtNumero.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }



}
