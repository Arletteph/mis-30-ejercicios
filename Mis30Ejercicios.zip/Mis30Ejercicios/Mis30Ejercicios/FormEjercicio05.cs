﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mis30Ejercicios
{
    public partial class FormEjercicio05 : Form
    {
        public FormEjercicio05()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtMinutos.Text, out int minutos) && minutos >= 0)
            {
                int dias = minutos / 1440;
                int horas = (minutos % 1440) / 60;
                int minutosRestantes = minutos % 60;

                // Formato profesional (ej: "02d 05h 30m")  
                lblResultado.Text = $"{dias:D2}d {horas:D2}h {minutosRestantes:D2}m";

            }
            else
            {
                MessageBox.Show("Ingrese minutos válidos (≥ 0).", "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void btnLimpiar_Click_1(object sender, EventArgs e)
        {
            txtMinutos.Clear();
            lblResultado.Text = "Resultado";
            txtMinutos.Focus();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }

}
