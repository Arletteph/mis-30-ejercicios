﻿
namespace Mis30Ejercicios
{
    partial class FormEjercicio04
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormEjercicio04));
            txtSegundos = new TextBox();
            lblResultado = new Label();
            btnCalcular = new Button();
            button1 = new Button();
            button2 = new Button();
            lblReloj = new Label();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // txtSegundos
            // 
            txtSegundos.Location = new Point(273, 155);
            txtSegundos.Name = "txtSegundos";
            txtSegundos.Size = new Size(100, 23);
            txtSegundos.TabIndex = 0;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.BackColor = Color.PaleGreen;
            lblResultado.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblResultado.Location = new Point(166, 236);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(73, 18);
            lblResultado.TabIndex = 1;
            lblResultado.Text = "Resultado:";
            // 
            // btnCalcular
            // 
            btnCalcular.BackColor = Color.PaleGreen;
            btnCalcular.Font = new Font("Sylfaen", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCalcular.Location = new Point(241, 304);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(87, 33);
            btnCalcular.TabIndex = 2;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = false;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.PaleGreen;
            button1.Font = new Font("Sylfaen", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(349, 302);
            button1.Name = "button1";
            button1.Size = new Size(91, 35);
            button1.TabIndex = 3;
            button1.Text = "Limpiar";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.PaleGreen;
            button2.Font = new Font("Sylfaen", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(145, 304);
            button2.Name = "button2";
            button2.Size = new Size(80, 34);
            button2.TabIndex = 4;
            button2.Text = "Volver";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // lblReloj
            // 
            lblReloj.AutoSize = true;
            lblReloj.BackColor = Color.PaleGreen;
            lblReloj.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblReloj.Location = new Point(166, 201);
            lblReloj.Name = "lblReloj";
            lblReloj.Size = new Size(44, 18);
            lblReloj.TabIndex = 5;
            lblReloj.Text = "00:00";
            lblReloj.Click += lblReloj_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.PaleGreen;
            label1.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(134, 160);
            label1.Name = "label1";
            label1.Size = new Size(135, 18);
            label1.TabIndex = 6;
            label1.Text = "Ingresa los segundos";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.PaleGreen;
            label2.BorderStyle = BorderStyle.FixedSingle;
            label2.Font = new Font("Sylfaen", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(189, 83);
            label2.Name = "label2";
            label2.Size = new Size(234, 27);
            label2.TabIndex = 7;
            label2.Text = "Calculadora de segundos";
            // 
            // FormEjercicio04
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(638, 366);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(lblReloj);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(btnCalcular);
            Controls.Add(lblResultado);
            Controls.Add(txtSegundos);
            Name = "FormEjercicio04";
            Text = "FormEjercicio04";
            ResumeLayout(false);
            PerformLayout();
        }



        #endregion

        private TextBox txtSegundos;
        private Label lblResultado;
        private Button btnCalcular;
        private Button button1;
        private Button button2;
        private Label lblReloj;
        private Label label1;
        private Label label2;
    }
}