﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mis30Ejercicios
{
    public partial class FormEjercicio24 : Form
    {
        public FormEjercicio24()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtRadio.Text, out double radio))
            {
                // Validar que el radio sea positivo
                if (radio <= 0)
                {
                    lblResultado.Text = "Error: El radio debe ser mayor a cero.";

                    return;
                }

                // Calcular resultados
                double longitud = 2 * Math.PI * radio;
                double area = Math.Round(Math.PI * Math.Pow(radio, 2), 2);
                double volumen = Math.Round((4.0 / 3) * Math.PI * Math.Pow(radio, 3), 2);

                // Mostrar resultados
                lblResultado.Text = $"""
            Longitud de la circunferencia: {Math.Round(longitud, 2)}
            Área del círculo: {area}
            Volumen de la esfera: {volumen}
            """;

            }
            else
            {
                MessageBox.Show("Ingrese un valor numérico válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtRadio.Clear();
            lblResultado.Text = "Resultado";
            txtRadio.Focus();
        }
    }

}
