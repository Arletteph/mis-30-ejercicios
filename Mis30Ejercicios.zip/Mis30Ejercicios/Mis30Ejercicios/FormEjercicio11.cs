﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mis30Ejercicios
{
    public partial class FormEjercicio11 : Form
    {
        public FormEjercicio11()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double precio, cantidad, precioventa, iva, preciobruto, descuento, totalpagar;

            if (!double.TryParse(txtPrecio.Text, out precio) || !double.TryParse(txtCantidad.Text, out cantidad))
            {
                MessageBox.Show("Por favor, introduce valores numéricos válidos.");
                return;
            }

            precioventa = precio * cantidad;
            iva = Math.Round(precioventa * 0.15, 2);
            preciobruto = precioventa + iva;

            if (preciobruto > 50)
                descuento = Math.Round(preciobruto * 0.05, 2);
            else
                descuento = 0;

            totalpagar = preciobruto - descuento;

            lblResultado.Text = "Datos de la factura\n" +
                                $"Precio de venta: {precioventa:C2}\n" +
                                $"IVA (15%): {iva:C2}\n" +
                                $"Precio bruto: {preciobruto:C2}\n" +
                                $"Descuento: {descuento:C2}\n" +
                                $"Total a pagar: {totalpagar:C2}";
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtPrecio.Clear();
            txtCantidad.Clear();
            lblResultado.Text = "";
            txtPrecio.Focus();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }

}
