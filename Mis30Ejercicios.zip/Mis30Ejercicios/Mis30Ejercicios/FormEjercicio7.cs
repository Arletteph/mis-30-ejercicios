﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mis30Ejercicios
{
    public partial class FormEjercicio7 : Form
    {
        private double _sumaTotal = 0; // Acumula la suma de salarios  
        private int _trabajadoresRegistrados = 0;
        private int _totalTrabajadores = 0;


        public FormEjercicio7()
        {
            InitializeComponent();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (_trabajadoresRegistrados < _totalTrabajadores &&
                double.TryParse(txtHoras.Text, out double horas) &&
                double.TryParse(txtTarifa.Text, out double tarifa) &&
                horas > 0 && tarifa > 0)
            {
                double salario;
                if (horas <= 40)
                {
                    salario = horas * tarifa;
                }
                else
                {
                    double horasExtra = horas - 40;
                    salario = (40 * tarifa) + (horasExtra * tarifa * 1.5);
                }

                _sumaTotal += salario;
                _trabajadoresRegistrados++;


                lstTrabajadores.Items.Add($"Trabajador {_trabajadoresRegistrados}: ${salario:F2}");

                // Limpiar campos para el siguiente trabajador  
                txtHoras.Clear();
                txtTarifa.Clear();

                if (_trabajadoresRegistrados == _totalTrabajadores)
                {
                    MessageBox.Show("¡Todos los trabajadores han sido registrados!", "Listo");
                    btnAgregar.Enabled = false;
                }
            }
            else
            {
                MessageBox.Show("Ingrese valores válidos (horas/tarifa > 0).", "Error");
            }
        }

        private void txtNumTrabajadores_TextChanged(object sender, EventArgs e)
        {
            if (int.TryParse(txtNumTrabajadores.Text, out int num) && num > 0)
            {
                _totalTrabajadores = num;
                btnAgregar.Enabled = true;
            }
        }


        private void btnCalcularSuma_Click(object sender, EventArgs e)
        {

            lblSumaTotal.Text = $"Suma total de salarios: ${_sumaTotal:F2}";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtNumTrabajadores.Clear();  
            txtHoras.Clear();            
            txtTarifa.Clear();           
            lblSumaTotal.Text = "$0.00"; 
        }
    
    }
}
