﻿namespace Mis30Ejercicios
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            menuStrip1 = new MenuStrip();
            ejercicios110ToolStripMenuItem = new ToolStripMenuItem();
            ejercicio01ToolStripMenuItem = new ToolStripMenuItem();
            ejercicio2ToolStripMenuItem = new ToolStripMenuItem();
            ejercicio3ToolStripMenuItem = new ToolStripMenuItem();
            ejercicio4ToolStripMenuItem = new ToolStripMenuItem();
            ejercicio5ToolStripMenuItem = new ToolStripMenuItem();
            ejercicio6ToolStripMenuItem = new ToolStripMenuItem();
            ejercicio7ToolStripMenuItem = new ToolStripMenuItem();
            ejercicio8ToolStripMenuItem = new ToolStripMenuItem();
            ejercicio9ToolStripMenuItem = new ToolStripMenuItem();
            ejercicio10ToolStripMenuItem = new ToolStripMenuItem();
            eToolStripMenuItem = new ToolStripMenuItem();
            ejercicio11ToolStripMenuItem = new ToolStripMenuItem();
            ejercicio12ToolStripMenuItem = new ToolStripMenuItem();
            ejercicio13ToolStripMenuItem = new ToolStripMenuItem();
            ejercicio14ToolStripMenuItem = new ToolStripMenuItem();
            ejercicio15ToolStripMenuItem = new ToolStripMenuItem();
            ejercicio16ToolStripMenuItem = new ToolStripMenuItem();
            ejercicio17ToolStripMenuItem = new ToolStripMenuItem();
            ejercicio18ToolStripMenuItem = new ToolStripMenuItem();
            ejercicio19ToolStripMenuItem = new ToolStripMenuItem();
            ejercicio20ToolStripMenuItem = new ToolStripMenuItem();
            ejercicios2130ToolStripMenuItem = new ToolStripMenuItem();
            ejercicio21ToolStripMenuItem = new ToolStripMenuItem();
            ejercicio22ToolStripMenuItem = new ToolStripMenuItem();
            ejercicio23ToolStripMenuItem = new ToolStripMenuItem();
            ejercicio24ToolStripMenuItem = new ToolStripMenuItem();
            ejercicio25ToolStripMenuItem = new ToolStripMenuItem();
            ejercicio26ToolStripMenuItem = new ToolStripMenuItem();
            ejercicio27ToolStripMenuItem = new ToolStripMenuItem();
            ejercicio28ToolStripMenuItem = new ToolStripMenuItem();
            ejercicio29ToolStripMenuItem = new ToolStripMenuItem();
            ejercicio30ToolStripMenuItem = new ToolStripMenuItem();
            label1 = new Label();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { ejercicios110ToolStripMenuItem, eToolStripMenuItem, ejercicios2130ToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(717, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // ejercicios110ToolStripMenuItem
            // 
            ejercicios110ToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { ejercicio01ToolStripMenuItem, ejercicio2ToolStripMenuItem, ejercicio3ToolStripMenuItem, ejercicio4ToolStripMenuItem, ejercicio5ToolStripMenuItem, ejercicio6ToolStripMenuItem, ejercicio7ToolStripMenuItem, ejercicio8ToolStripMenuItem, ejercicio9ToolStripMenuItem, ejercicio10ToolStripMenuItem });
            ejercicios110ToolStripMenuItem.Font = new Font("Corbel", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ejercicios110ToolStripMenuItem.Name = "ejercicios110ToolStripMenuItem";
            ejercicios110ToolStripMenuItem.Size = new Size(98, 20);
            ejercicios110ToolStripMenuItem.Text = "Ejercicios 1-10";
            // 
            // ejercicio01ToolStripMenuItem
            // 
            ejercicio01ToolStripMenuItem.Name = "ejercicio01ToolStripMenuItem";
            ejercicio01ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio01ToolStripMenuItem.Text = "Ejercicio 1";
            ejercicio01ToolStripMenuItem.Click += ejercicio01ToolStripMenuItem_Click;
            // 
            // ejercicio2ToolStripMenuItem
            // 
            ejercicio2ToolStripMenuItem.Name = "ejercicio2ToolStripMenuItem";
            ejercicio2ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio2ToolStripMenuItem.Text = "Ejercicio 2";
            ejercicio2ToolStripMenuItem.Click += ejercicio2ToolStripMenuItem_Click;
            // 
            // ejercicio3ToolStripMenuItem
            // 
            ejercicio3ToolStripMenuItem.Name = "ejercicio3ToolStripMenuItem";
            ejercicio3ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio3ToolStripMenuItem.Text = "Ejercicio 3";
            ejercicio3ToolStripMenuItem.Click += ejercicio3ToolStripMenuItem_Click;
            // 
            // ejercicio4ToolStripMenuItem
            // 
            ejercicio4ToolStripMenuItem.Name = "ejercicio4ToolStripMenuItem";
            ejercicio4ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio4ToolStripMenuItem.Text = "Ejercicio 4";
            ejercicio4ToolStripMenuItem.Click += ejercicio4ToolStripMenuItem_Click;
            // 
            // ejercicio5ToolStripMenuItem
            // 
            ejercicio5ToolStripMenuItem.Name = "ejercicio5ToolStripMenuItem";
            ejercicio5ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio5ToolStripMenuItem.Text = "Ejercicio 5";
            ejercicio5ToolStripMenuItem.Click += ejercicio5ToolStripMenuItem_Click_1;
            // 
            // ejercicio6ToolStripMenuItem
            // 
            ejercicio6ToolStripMenuItem.Name = "ejercicio6ToolStripMenuItem";
            ejercicio6ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio6ToolStripMenuItem.Text = "Ejercicio 6";
            ejercicio6ToolStripMenuItem.Click += ejercicio6ToolStripMenuItem_Click;
            // 
            // ejercicio7ToolStripMenuItem
            // 
            ejercicio7ToolStripMenuItem.Name = "ejercicio7ToolStripMenuItem";
            ejercicio7ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio7ToolStripMenuItem.Text = "Ejercicio 7";
            ejercicio7ToolStripMenuItem.Click += ejercicio7ToolStripMenuItem_Click;
            // 
            // ejercicio8ToolStripMenuItem
            // 
            ejercicio8ToolStripMenuItem.Name = "ejercicio8ToolStripMenuItem";
            ejercicio8ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio8ToolStripMenuItem.Text = "Ejercicio 8";
            ejercicio8ToolStripMenuItem.Click += ejercicio8ToolStripMenuItem_Click;
            // 
            // ejercicio9ToolStripMenuItem
            // 
            ejercicio9ToolStripMenuItem.Name = "ejercicio9ToolStripMenuItem";
            ejercicio9ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio9ToolStripMenuItem.Text = "Ejercicio 9";
            ejercicio9ToolStripMenuItem.Click += ejercicio9ToolStripMenuItem_Click;
            // 
            // ejercicio10ToolStripMenuItem
            // 
            ejercicio10ToolStripMenuItem.Name = "ejercicio10ToolStripMenuItem";
            ejercicio10ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio10ToolStripMenuItem.Text = "Ejercicio 10";
            ejercicio10ToolStripMenuItem.Click += ejercicio10ToolStripMenuItem_Click;
            // 
            // eToolStripMenuItem
            // 
            eToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { ejercicio11ToolStripMenuItem, ejercicio12ToolStripMenuItem, ejercicio13ToolStripMenuItem, ejercicio14ToolStripMenuItem, ejercicio15ToolStripMenuItem, ejercicio16ToolStripMenuItem, ejercicio17ToolStripMenuItem, ejercicio18ToolStripMenuItem, ejercicio19ToolStripMenuItem, ejercicio20ToolStripMenuItem });
            eToolStripMenuItem.Font = new Font("Corbel", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            eToolStripMenuItem.Name = "eToolStripMenuItem";
            eToolStripMenuItem.Size = new Size(101, 20);
            eToolStripMenuItem.Text = "Ejercicos 11-20";
            // 
            // ejercicio11ToolStripMenuItem
            // 
            ejercicio11ToolStripMenuItem.Name = "ejercicio11ToolStripMenuItem";
            ejercicio11ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio11ToolStripMenuItem.Text = "Ejercicio 11";
            ejercicio11ToolStripMenuItem.Click += ejercicio11ToolStripMenuItem_Click;
            // 
            // ejercicio12ToolStripMenuItem
            // 
            ejercicio12ToolStripMenuItem.Name = "ejercicio12ToolStripMenuItem";
            ejercicio12ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio12ToolStripMenuItem.Text = "Ejercicio 12";
            ejercicio12ToolStripMenuItem.Click += ejercicio12ToolStripMenuItem_Click;
            // 
            // ejercicio13ToolStripMenuItem
            // 
            ejercicio13ToolStripMenuItem.Name = "ejercicio13ToolStripMenuItem";
            ejercicio13ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio13ToolStripMenuItem.Text = "Ejercicio 13";
            ejercicio13ToolStripMenuItem.Click += ejercicio13ToolStripMenuItem_Click;
            // 
            // ejercicio14ToolStripMenuItem
            // 
            ejercicio14ToolStripMenuItem.Name = "ejercicio14ToolStripMenuItem";
            ejercicio14ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio14ToolStripMenuItem.Text = "Ejercicio 14";
            ejercicio14ToolStripMenuItem.Click += ejercicio14ToolStripMenuItem_Click;
            // 
            // ejercicio15ToolStripMenuItem
            // 
            ejercicio15ToolStripMenuItem.Name = "ejercicio15ToolStripMenuItem";
            ejercicio15ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio15ToolStripMenuItem.Text = "Ejercicio 15";
            ejercicio15ToolStripMenuItem.Click += ejercicio15ToolStripMenuItem_Click;
            // 
            // ejercicio16ToolStripMenuItem
            // 
            ejercicio16ToolStripMenuItem.Name = "ejercicio16ToolStripMenuItem";
            ejercicio16ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio16ToolStripMenuItem.Text = "Ejercicio 16";
            ejercicio16ToolStripMenuItem.Click += ejercicio16ToolStripMenuItem_Click;
            // 
            // ejercicio17ToolStripMenuItem
            // 
            ejercicio17ToolStripMenuItem.Name = "ejercicio17ToolStripMenuItem";
            ejercicio17ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio17ToolStripMenuItem.Text = "Ejercicio 17";
            ejercicio17ToolStripMenuItem.Click += ejercicio17ToolStripMenuItem_Click;
            // 
            // ejercicio18ToolStripMenuItem
            // 
            ejercicio18ToolStripMenuItem.Name = "ejercicio18ToolStripMenuItem";
            ejercicio18ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio18ToolStripMenuItem.Text = "Ejercicio 18";
            ejercicio18ToolStripMenuItem.Click += ejercicio18ToolStripMenuItem_Click;
            // 
            // ejercicio19ToolStripMenuItem
            // 
            ejercicio19ToolStripMenuItem.Name = "ejercicio19ToolStripMenuItem";
            ejercicio19ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio19ToolStripMenuItem.Text = "Ejercicio 19";
            ejercicio19ToolStripMenuItem.Click += ejercicio19ToolStripMenuItem_Click;
            // 
            // ejercicio20ToolStripMenuItem
            // 
            ejercicio20ToolStripMenuItem.Name = "ejercicio20ToolStripMenuItem";
            ejercicio20ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio20ToolStripMenuItem.Text = "Ejercicio 20";
            ejercicio20ToolStripMenuItem.Click += ejercicio20ToolStripMenuItem_Click;
            // 
            // ejercicios2130ToolStripMenuItem
            // 
            ejercicios2130ToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { ejercicio21ToolStripMenuItem, ejercicio22ToolStripMenuItem, ejercicio23ToolStripMenuItem, ejercicio24ToolStripMenuItem, ejercicio25ToolStripMenuItem, ejercicio26ToolStripMenuItem, ejercicio27ToolStripMenuItem, ejercicio28ToolStripMenuItem, ejercicio29ToolStripMenuItem, ejercicio30ToolStripMenuItem });
            ejercicios2130ToolStripMenuItem.Font = new Font("Corbel", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ejercicios2130ToolStripMenuItem.Name = "ejercicios2130ToolStripMenuItem";
            ejercicios2130ToolStripMenuItem.Size = new Size(104, 20);
            ejercicios2130ToolStripMenuItem.Text = "Ejercicios 21-30";
            // 
            // ejercicio21ToolStripMenuItem
            // 
            ejercicio21ToolStripMenuItem.Name = "ejercicio21ToolStripMenuItem";
            ejercicio21ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio21ToolStripMenuItem.Text = "Ejercicio 21";
            ejercicio21ToolStripMenuItem.Click += ejercicio21ToolStripMenuItem_Click;
            // 
            // ejercicio22ToolStripMenuItem
            // 
            ejercicio22ToolStripMenuItem.Name = "ejercicio22ToolStripMenuItem";
            ejercicio22ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio22ToolStripMenuItem.Text = "Ejercicio 22";
            ejercicio22ToolStripMenuItem.Click += ejercicio22ToolStripMenuItem_Click;
            // 
            // ejercicio23ToolStripMenuItem
            // 
            ejercicio23ToolStripMenuItem.Name = "ejercicio23ToolStripMenuItem";
            ejercicio23ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio23ToolStripMenuItem.Text = "Ejercicio 23";
            ejercicio23ToolStripMenuItem.Click += ejercicio23ToolStripMenuItem_Click;
            // 
            // ejercicio24ToolStripMenuItem
            // 
            ejercicio24ToolStripMenuItem.Name = "ejercicio24ToolStripMenuItem";
            ejercicio24ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio24ToolStripMenuItem.Text = "Ejercicio 24";
            ejercicio24ToolStripMenuItem.Click += ejercicio24ToolStripMenuItem_Click;
            // 
            // ejercicio25ToolStripMenuItem
            // 
            ejercicio25ToolStripMenuItem.Name = "ejercicio25ToolStripMenuItem";
            ejercicio25ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio25ToolStripMenuItem.Text = "Ejercicio 25";
            ejercicio25ToolStripMenuItem.Click += ejercicio25ToolStripMenuItem_Click;
            // 
            // ejercicio26ToolStripMenuItem
            // 
            ejercicio26ToolStripMenuItem.Name = "ejercicio26ToolStripMenuItem";
            ejercicio26ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio26ToolStripMenuItem.Text = "Ejercicio 26";
            ejercicio26ToolStripMenuItem.Click += ejercicio26ToolStripMenuItem_Click;
            // 
            // ejercicio27ToolStripMenuItem
            // 
            ejercicio27ToolStripMenuItem.Name = "ejercicio27ToolStripMenuItem";
            ejercicio27ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio27ToolStripMenuItem.Text = "Ejercicio 27";
            ejercicio27ToolStripMenuItem.Click += ejercicio27ToolStripMenuItem_Click;
            // 
            // ejercicio28ToolStripMenuItem
            // 
            ejercicio28ToolStripMenuItem.Name = "ejercicio28ToolStripMenuItem";
            ejercicio28ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio28ToolStripMenuItem.Text = "Ejercicio 28";
            ejercicio28ToolStripMenuItem.Click += ejercicio28ToolStripMenuItem_Click;
            // 
            // ejercicio29ToolStripMenuItem
            // 
            ejercicio29ToolStripMenuItem.Name = "ejercicio29ToolStripMenuItem";
            ejercicio29ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio29ToolStripMenuItem.Text = "Ejercicio 29";
            ejercicio29ToolStripMenuItem.Click += ejercicio29ToolStripMenuItem_Click;
            // 
            // ejercicio30ToolStripMenuItem
            // 
            ejercicio30ToolStripMenuItem.Name = "ejercicio30ToolStripMenuItem";
            ejercicio30ToolStripMenuItem.Size = new Size(180, 22);
            ejercicio30ToolStripMenuItem.Text = "Ejercicio 30";
            ejercicio30ToolStripMenuItem.Click += ejercicio30ToolStripMenuItem_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Cascadia Code SemiBold", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(61, 318);
            label1.Name = "label1";
            label1.Size = new Size(602, 32);
            label1.TabIndex = 1;
            label1.Text = "Mis 30 Ejercicios by Arlette Pérez Hiciano";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(717, 377);
            Controls.Add(label1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Form1";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem ejercicios110ToolStripMenuItem;
        private ToolStripMenuItem ejercicio01ToolStripMenuItem;
        private ToolStripMenuItem ejercicio2ToolStripMenuItem;
        private ToolStripMenuItem ejercicio3ToolStripMenuItem;
        private ToolStripMenuItem ejercicio4ToolStripMenuItem;
        private ToolStripMenuItem ejercicio5ToolStripMenuItem;
        private ToolStripMenuItem ejercicio6ToolStripMenuItem;
        private ToolStripMenuItem ejercicio7ToolStripMenuItem;
        private ToolStripMenuItem ejercicio8ToolStripMenuItem;
        private ToolStripMenuItem ejercicio9ToolStripMenuItem;
        private ToolStripMenuItem ejercicio10ToolStripMenuItem;
        private ToolStripMenuItem eToolStripMenuItem;
        private ToolStripMenuItem ejercicio11ToolStripMenuItem;
        private ToolStripMenuItem ejercicio12ToolStripMenuItem;
        private ToolStripMenuItem ejercicio13ToolStripMenuItem;
        private ToolStripMenuItem ejercicio14ToolStripMenuItem;
        private ToolStripMenuItem ejercicio15ToolStripMenuItem;
        private ToolStripMenuItem ejercicio16ToolStripMenuItem;
        private ToolStripMenuItem ejercicio17ToolStripMenuItem;
        private ToolStripMenuItem ejercicio18ToolStripMenuItem;
        private ToolStripMenuItem ejercicio19ToolStripMenuItem;
        private ToolStripMenuItem ejercicio20ToolStripMenuItem;
        private ToolStripMenuItem ejercicios2130ToolStripMenuItem;
        private ToolStripMenuItem ejercicio21ToolStripMenuItem;
        private ToolStripMenuItem ejercicio22ToolStripMenuItem;
        private ToolStripMenuItem ejercicio23ToolStripMenuItem;
        private ToolStripMenuItem ejercicio24ToolStripMenuItem;
        private ToolStripMenuItem ejercicio25ToolStripMenuItem;
        private ToolStripMenuItem ejercicio26ToolStripMenuItem;
        private ToolStripMenuItem ejercicio27ToolStripMenuItem;
        private ToolStripMenuItem ejercicio28ToolStripMenuItem;
        private ToolStripMenuItem ejercicio29ToolStripMenuItem;
        private ToolStripMenuItem ejercicio30ToolStripMenuItem;
        private Label label1;
    }
}
