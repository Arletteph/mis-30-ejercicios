﻿namespace Mis30Ejercicios
{
    partial class FormEjercicio08
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtHoras = new TextBox();
            txtTarifa = new TextBox();
            btnCalcular = new Button();
            btnLimpiar = new Button();
            button1 = new Button();
            lblResultado = new Label();
            label3 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Cornsilk;
            label1.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold);
            label1.Location = new Point(151, 135);
            label1.Name = "label1";
            label1.Size = new Size(117, 18);
            label1.TabIndex = 0;
            label1.Text = "Horas Trabajadas";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Cornsilk;
            label2.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold);
            label2.Location = new Point(151, 186);
            label2.Name = "label2";
            label2.Size = new Size(108, 18);
            label2.TabIndex = 1;
            label2.Text = "Tarifa por Hora";
            // 
            // txtHoras
            // 
            txtHoras.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold);
            txtHoras.Location = new Point(301, 134);
            txtHoras.Name = "txtHoras";
            txtHoras.Size = new Size(100, 25);
            txtHoras.TabIndex = 2;
            // 
            // txtTarifa
            // 
            txtTarifa.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold);
            txtTarifa.Location = new Point(298, 183);
            txtTarifa.Name = "txtTarifa";
            txtTarifa.Size = new Size(100, 25);
            txtTarifa.TabIndex = 3;
            // 
            // btnCalcular
            // 
            btnCalcular.BackColor = Color.Cornsilk;
            btnCalcular.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            btnCalcular.Location = new Point(309, 271);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(76, 31);
            btnCalcular.TabIndex = 4;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = false;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnLimpiar
            // 
            btnLimpiar.BackColor = Color.Cornsilk;
            btnLimpiar.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            btnLimpiar.Location = new Point(428, 272);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(82, 31);
            btnLimpiar.TabIndex = 5;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = false;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Cornsilk;
            button1.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            button1.Location = new Point(186, 271);
            button1.Name = "button1";
            button1.Size = new Size(75, 31);
            button1.TabIndex = 6;
            button1.Text = "Volver";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.BackColor = Color.Cornsilk;
            lblResultado.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold);
            lblResultado.Location = new Point(445, 173);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(77, 18);
            lblResultado.TabIndex = 7;
            lblResultado.Text = "Resultado: ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Cornsilk;
            label3.Font = new Font("Sylfaen", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(259, 69);
            label3.Name = "label3";
            label3.Size = new Size(180, 25);
            label3.TabIndex = 8;
            label3.Text = " Cálculo de Salario";
            // 
            // FormEjercicio08
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.descarga__26_;
            ClientSize = new Size(682, 376);
            Controls.Add(label3);
            Controls.Add(lblResultado);
            Controls.Add(button1);
            Controls.Add(btnLimpiar);
            Controls.Add(btnCalcular);
            Controls.Add(txtTarifa);
            Controls.Add(txtHoras);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "FormEjercicio08";
            Text = "FormEjercicio08";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtHoras;
        private TextBox txtTarifa;
        private Button btnCalcular;
        private Button btnLimpiar;
        private Button button1;
        private Label lblResultado;
        private Label label3;
    }
}