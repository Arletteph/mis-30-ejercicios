﻿namespace Mis30Ejercicios
{
    partial class FormEjercicio12
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnAgregar = new Button();
            btnLimpiar = new Button();
            txtNumero = new TextBox();
            lstNumeros = new ListBox();
            btnCalcular = new Button();
            lblPositivos = new Label();
            lblNegativos = new Label();
            lblPares = new Label();
            lblImpares = new Label();
            button1 = new Button();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // btnAgregar
            // 
            btnAgregar.BackColor = Color.Pink;
            btnAgregar.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            btnAgregar.Location = new Point(414, 131);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(83, 30);
            btnAgregar.TabIndex = 0;
            btnAgregar.Text = "Ingresar número";
            btnAgregar.UseVisualStyleBackColor = false;
            btnAgregar.Click += btnAgregar_Click;
            // 
            // btnLimpiar
            // 
            btnLimpiar.BackColor = Color.Pink;
            btnLimpiar.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            btnLimpiar.Location = new Point(298, 188);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(83, 30);
            btnLimpiar.TabIndex = 3;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = false;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // txtNumero
            // 
            txtNumero.Location = new Point(270, 131);
            txtNumero.Name = "txtNumero";
            txtNumero.Size = new Size(111, 23);
            txtNumero.TabIndex = 4;
            // 
            // lstNumeros
            // 
            lstNumeros.FormattingEnabled = true;
            lstNumeros.ItemHeight = 15;
            lstNumeros.Location = new Point(15, 29);
            lstNumeros.Name = "lstNumeros";
            lstNumeros.Size = new Size(120, 94);
            lstNumeros.TabIndex = 5;
            // 
            // btnCalcular
            // 
            btnCalcular.BackColor = Color.Pink;
            btnCalcular.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            btnCalcular.Location = new Point(414, 191);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(83, 30);
            btnCalcular.TabIndex = 6;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = false;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // lblPositivos
            // 
            lblPositivos.AutoSize = true;
            lblPositivos.BackColor = Color.Pink;
            lblPositivos.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            lblPositivos.Location = new Point(14, 232);
            lblPositivos.Name = "lblPositivos";
            lblPositivos.Size = new Size(79, 22);
            lblPositivos.TabIndex = 7;
            lblPositivos.Text = "Positivos";
            lblPositivos.Click += lblPositivos_Click;
            // 
            // lblNegativos
            // 
            lblNegativos.AutoSize = true;
            lblNegativos.BackColor = Color.Pink;
            lblNegativos.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            lblNegativos.Location = new Point(12, 262);
            lblNegativos.Name = "lblNegativos";
            lblNegativos.Size = new Size(85, 22);
            lblNegativos.TabIndex = 8;
            lblNegativos.Text = "Negativos";
            // 
            // lblPares
            // 
            lblPares.AutoSize = true;
            lblPares.BackColor = Color.Pink;
            lblPares.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            lblPares.Location = new Point(11, 292);
            lblPares.Name = "lblPares";
            lblPares.Size = new Size(79, 22);
            lblPares.TabIndex = 9;
            lblPares.Text = "Positivos";
            // 
            // lblImpares
            // 
            lblImpares.AutoSize = true;
            lblImpares.BackColor = Color.Pink;
            lblImpares.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            lblImpares.Location = new Point(11, 317);
            lblImpares.Name = "lblImpares";
            lblImpares.Size = new Size(69, 22);
            lblImpares.TabIndex = 10;
            lblImpares.Text = "Impares";
            // 
            // button1
            // 
            button1.BackColor = Color.Pink;
            button1.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            button1.Location = new Point(178, 188);
            button1.Name = "button1";
            button1.Size = new Size(83, 30);
            button1.TabIndex = 11;
            button1.Text = "Volver";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Pink;
            label1.Font = new Font("Sylfaen", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(270, 73);
            label1.Name = "label1";
            label1.Size = new Size(104, 27);
            label1.TabIndex = 12;
            label1.Text = "Contador";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(126, 131);
            label2.Name = "label2";
            label2.Size = new Size(122, 18);
            label2.TabIndex = 13;
            label2.Text = "Ingresa el numero";
            // 
            // FormEjercicio12
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.ejercicio2;
            ClientSize = new Size(632, 344);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(lblImpares);
            Controls.Add(lblPares);
            Controls.Add(lblNegativos);
            Controls.Add(lblPositivos);
            Controls.Add(btnCalcular);
            Controls.Add(lstNumeros);
            Controls.Add(txtNumero);
            Controls.Add(btnLimpiar);
            Controls.Add(btnAgregar);
            Name = "FormEjercicio12";
            Text = "FormEjercicio12";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnAgregar;
        private Button btnLimpiar;
        private TextBox txtNumero;
        private ListBox lstNumeros;
        private Button btnCalcular;
        private Label lblPositivos;
        private Label lblNegativos;
        private Label lblPares;
        private Label lblImpares;
        private Button button1;
        private Label label1;
        private Label label2;
    }
}