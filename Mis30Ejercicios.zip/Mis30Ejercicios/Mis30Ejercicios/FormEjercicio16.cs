﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mis30Ejercicios
{
    public partial class FormEjercicio16 : Form
    {
        private bool vocalEncontrada = false;
        private string primeraVocal = "";
        public FormEjercicio16()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (vocalEncontrada)
            {
                MessageBox.Show("Ya se encontró la primera vocal.", "Listo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (txtCaracter.Text.Length == 1) // Asegura que solo sea 1 carácter
            {
                char caracter = char.ToLower(txtCaracter.Text[0]); // Convierte a minúscula

                if ("aeiou".Contains(caracter))
                {
                    primeraVocal = caracter.ToString();
                    vocalEncontrada = true;
                    lblResultado.Text = $"Primera vocal encontrada: '{primeraVocal}'";
                    lblMensaje.Text = "¡Vocal detectada!";
                }
                else
                {
                    lblMensaje.Text = $"'{caracter}' no es vocal. Sigue intentando.";
                }
                txtCaracter.Clear();
            }
            else
            {
                MessageBox.Show("Ingresa solo un carácter.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            txtCaracter.Focus();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            vocalEncontrada = false;
            primeraVocal = "";
            txtCaracter.Clear();
            lblResultado.Text = "Resultado";
            lblMensaje.Text = "Ingresa un carácter:";
            txtCaracter.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

}
