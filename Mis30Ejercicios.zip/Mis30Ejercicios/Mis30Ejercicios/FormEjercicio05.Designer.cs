﻿namespace Mis30Ejercicios
{
    partial class FormEjercicio05
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtMinutos = new TextBox();
            btnCalcular = new Button();
            btnLimpiar = new Button();
            button2 = new Button();
            lblResultado = new Label();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // txtMinutos
            // 
            txtMinutos.Location = new Point(305, 163);
            txtMinutos.Name = "txtMinutos";
            txtMinutos.Size = new Size(100, 23);
            txtMinutos.TabIndex = 0;
            // 
            // btnCalcular
            // 
            btnCalcular.BackColor = SystemColors.ScrollBar;
            btnCalcular.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            btnCalcular.Location = new Point(318, 260);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(83, 29);
            btnCalcular.TabIndex = 1;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = false;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnLimpiar
            // 
            btnLimpiar.BackColor = SystemColors.ScrollBar;
            btnLimpiar.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            btnLimpiar.Location = new Point(420, 260);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(83, 29);
            btnLimpiar.TabIndex = 2;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = false;
            btnLimpiar.Click += btnLimpiar_Click_1;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.ScrollBar;
            button2.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            button2.Location = new Point(221, 260);
            button2.Name = "button2";
            button2.Size = new Size(83, 29);
            button2.TabIndex = 3;
            button2.Text = "Volver";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.BackColor = SystemColors.ScrollBar;
            lblResultado.BorderStyle = BorderStyle.FixedSingle;
            lblResultado.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblResultado.Location = new Point(163, 211);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(75, 20);
            lblResultado.TabIndex = 4;
            lblResultado.Text = "Resultado:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Sylfaen", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(192, 113);
            label1.Name = "label1";
            label1.Size = new Size(311, 25);
            label1.TabIndex = 5;
            label1.Text = "Sistema de Cálculo de Días/Horas";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = SystemColors.ScrollBar;
            label2.BorderStyle = BorderStyle.FixedSingle;
            label2.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(163, 164);
            label2.Name = "label2";
            label2.Size = new Size(131, 20);
            label2.TabIndex = 6;
            label2.Text = "Ingresa los minutos";
            // 
            // FormEjercicio05
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.descarga__23_;
            ClientSize = new Size(731, 381);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(lblResultado);
            Controls.Add(button2);
            Controls.Add(btnLimpiar);
            Controls.Add(btnCalcular);
            Controls.Add(txtMinutos);
            Name = "FormEjercicio05";
            Text = "FormEjercicio05";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtMinutos;
        private Button btnCalcular;
        private Button btnLimpiar;
        private Button button2;
        private Label lblResultado;
        private Label label1;
        private Label label2;
    }
}