﻿namespace Mis30Ejercicios
{
    partial class FormEjercicio02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormEjercicio02));
            textBox1 = new TextBox();
            button1 = new Button();
            label1 = new Label();
            label2 = new Label();
            button2 = new Button();
            button3 = new Button();
            cmbMoneda = new ComboBox();
            dtpFecha = new DateTimePicker();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.Location = new Point(225, 169);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(140, 23);
            textBox1.TabIndex = 0;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.GradientActiveCaption;
            button1.BackgroundImageLayout = ImageLayout.None;
            button1.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            button1.Location = new Point(265, 264);
            button1.Name = "button1";
            button1.Size = new Size(88, 35);
            button1.TabIndex = 1;
            button1.Text = "Calcular";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.GradientActiveCaption;
            label1.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            label1.Location = new Point(390, 179);
            label1.Name = "label1";
            label1.Size = new Size(106, 22);
            label1.TabIndex = 2;
            label1.Text = "Descuento: $";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = SystemColors.GradientActiveCaption;
            label2.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            label2.Location = new Point(390, 132);
            label2.Name = "label2";
            label2.Size = new Size(120, 22);
            label2.TabIndex = 3;
            label2.Text = "Sueldo Neto: $";
            // 
            // button2
            // 
            button2.BackColor = SystemColors.GradientActiveCaption;
            button2.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            button2.Location = new Point(379, 264);
            button2.Name = "button2";
            button2.Size = new Size(86, 35);
            button2.TabIndex = 4;
            button2.Text = "Limpiar";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.BackColor = SystemColors.GradientActiveCaption;
            button3.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            button3.Location = new Point(150, 264);
            button3.Name = "button3";
            button3.Size = new Size(86, 35);
            button3.TabIndex = 5;
            button3.Text = "Volver";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // cmbMoneda
            // 
            cmbMoneda.FormattingEnabled = true;
            cmbMoneda.Items.AddRange(new object[] { "Pesos", "Dólares", "Euros" });
            cmbMoneda.Location = new Point(225, 118);
            cmbMoneda.Name = "cmbMoneda";
            cmbMoneda.Size = new Size(140, 23);
            cmbMoneda.TabIndex = 6;
            cmbMoneda.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // dtpFecha
            // 
            dtpFecha.CalendarForeColor = Color.Transparent;
            dtpFecha.CalendarMonthBackground = Color.Transparent;
            dtpFecha.CalendarTitleBackColor = Color.Transparent;
            dtpFecha.CalendarTrailingForeColor = Color.Transparent;
            dtpFecha.Font = new Font("Sylfaen", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dtpFecha.Location = new Point(12, 12);
            dtpFecha.Name = "dtpFecha";
            dtpFecha.Size = new Size(253, 25);
            dtpFecha.TabIndex = 7;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.BorderStyle = BorderStyle.FixedSingle;
            label3.Font = new Font("Sylfaen", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(150, 76);
            label3.Name = "label3";
            label3.Size = new Size(290, 24);
            label3.TabIndex = 8;
            label3.Text = "Calculadora de Descuentos Salariales";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = SystemColors.GradientActiveCaption;
            label4.Font = new Font("Sylfaen", 12F, FontStyle.Italic);
            label4.Location = new Point(69, 118);
            label4.Name = "label4";
            label4.Size = new Size(150, 22);
            label4.TabIndex = 9;
            label4.Text = "Selecciona la moneda";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = SystemColors.GradientActiveCaption;
            label5.Font = new Font("Sylfaen", 12F, FontStyle.Italic);
            label5.Location = new Point(91, 170);
            label5.Name = "label5";
            label5.Size = new Size(120, 22);
            label5.TabIndex = 10;
            label5.Text = "Ingresa tu sueldo";
            // 
            // FormEjercicio02
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(623, 373);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(dtpFecha);
            Controls.Add(cmbMoneda);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(textBox1);
            Name = "FormEjercicio02";
            Text = "FormEjercicio02";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private Button button1;
        private Label label1;
        private Label label2;
        private Button button2;
        private Button button3;
        private ComboBox cmbMoneda;
        private DateTimePicker dtpFecha;
        private Label label3;
        private Label label4;
        private Label label5;
    }
}