﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mis30Ejercicios
{
    public partial class FormEjercicio03 : Form
    {
        public FormEjercicio03()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtMonto.Text, out double monto) && monto > 0)
            {
                double descuento;
                string porcentaje;

                if (monto > 100)
                {
                    descuento = monto * 0.10;
                    porcentaje = "10%";
                }
                else
                {
                    descuento = monto * 0.02;
                    porcentaje = "2%";
                }


                lblMonto.Text = $"Monto original: {monto:C2}";
                lblDescuento.Text = $"Descuento aplicado: {porcentaje} ({descuento:C2})";
                lblTotal.Text = $"Total con descuento: {monto - descuento:C2}";


                lblDescuento.ForeColor = Color.Red;
                lblTotal.ForeColor = Color.Green;
            }
            else
            {
                MessageBox.Show("Ingrese un monto válido (mayor a 0).", "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            txtMonto.Clear();
            lblMonto.Text = "Monto original:";
            lblDescuento.Text = "Descuento aplicado:";
            lblTotal.Text = "Total con descuento:";

            
            lblDescuento.ForeColor = SystemColors.ControlText; 
            lblTotal.ForeColor = SystemColors.ControlText;
        }
    }

}
