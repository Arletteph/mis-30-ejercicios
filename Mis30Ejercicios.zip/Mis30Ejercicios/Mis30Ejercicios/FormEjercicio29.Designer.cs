﻿namespace Mis30Ejercicios
{
    partial class FormEjercicio29
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtDeporte = new TextBox();
            lstDeportes = new ListBox();
            Volver = new Button();
            btnLimpiar = new Button();
            btnAgregar = new Button();
            lblVoley = new Label();
            lblFutbol = new Label();
            lblAjedrez = new Label();
            lblBasquet = new Label();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // txtDeporte
            // 
            txtDeporte.Location = new Point(195, 174);
            txtDeporte.Name = "txtDeporte";
            txtDeporte.Size = new Size(100, 23);
            txtDeporte.TabIndex = 0;
            // 
            // lstDeportes
            // 
            lstDeportes.FormattingEnabled = true;
            lstDeportes.ItemHeight = 15;
            lstDeportes.Location = new Point(29, 60);
            lstDeportes.Name = "lstDeportes";
            lstDeportes.Size = new Size(120, 94);
            lstDeportes.TabIndex = 1;
            // 
            // Volver
            // 
            Volver.BackColor = SystemColors.ScrollBar;
            Volver.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            Volver.Location = new Point(139, 248);
            Volver.Name = "Volver";
            Volver.Size = new Size(75, 29);
            Volver.TabIndex = 7;
            Volver.Text = "Volver";
            Volver.UseVisualStyleBackColor = false;
            // 
            // btnLimpiar
            // 
            btnLimpiar.BackColor = SystemColors.ScrollBar;
            btnLimpiar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            btnLimpiar.Location = new Point(220, 248);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(75, 29);
            btnLimpiar.TabIndex = 6;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = false;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // btnAgregar
            // 
            btnAgregar.BackColor = SystemColors.ScrollBar;
            btnAgregar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            btnAgregar.Location = new Point(301, 248);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(75, 27);
            btnAgregar.TabIndex = 5;
            btnAgregar.Text = "Agregar";
            btnAgregar.UseVisualStyleBackColor = false;
            btnAgregar.Click += btnAgregar_Click;
            // 
            // lblVoley
            // 
            lblVoley.AutoSize = true;
            lblVoley.BackColor = SystemColors.ScrollBar;
            lblVoley.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblVoley.Location = new Point(324, 100);
            lblVoley.Name = "lblVoley";
            lblVoley.Size = new Size(37, 15);
            lblVoley.TabIndex = 8;
            lblVoley.Text = "Voley";
            // 
            // lblFutbol
            // 
            lblFutbol.AutoSize = true;
            lblFutbol.BackColor = SystemColors.ScrollBar;
            lblFutbol.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblFutbol.Location = new Point(324, 139);
            lblFutbol.Name = "lblFutbol";
            lblFutbol.Size = new Size(42, 15);
            lblFutbol.TabIndex = 9;
            lblFutbol.Text = "Futbol";
            // 
            // lblAjedrez
            // 
            lblAjedrez.AutoSize = true;
            lblAjedrez.BackColor = SystemColors.ScrollBar;
            lblAjedrez.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblAjedrez.Location = new Point(325, 174);
            lblAjedrez.Name = "lblAjedrez";
            lblAjedrez.Size = new Size(45, 15);
            lblAjedrez.TabIndex = 10;
            lblAjedrez.Text = "Ajedez";
            // 
            // lblBasquet
            // 
            lblBasquet.AutoSize = true;
            lblBasquet.BackColor = SystemColors.ScrollBar;
            lblBasquet.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblBasquet.Location = new Point(324, 204);
            lblBasquet.Name = "lblBasquet";
            lblBasquet.Size = new Size(52, 15);
            lblBasquet.TabIndex = 11;
            lblBasquet.Text = "Basquet";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(75, 177);
            label1.Name = "label1";
            label1.Size = new Size(114, 15);
            label1.TabIndex = 12;
            label1.Text = "Ingrese un deporte";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.White;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(31, 38);
            label2.Name = "label2";
            label2.Size = new Size(59, 15);
            label2.TabIndex = 13;
            label2.Text = "Deportes";
            // 
            // FormEjercicio29
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.descarga__23_;
            ClientSize = new Size(568, 384);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(lblBasquet);
            Controls.Add(lblAjedrez);
            Controls.Add(lblFutbol);
            Controls.Add(lblVoley);
            Controls.Add(Volver);
            Controls.Add(btnLimpiar);
            Controls.Add(btnAgregar);
            Controls.Add(lstDeportes);
            Controls.Add(txtDeporte);
            Name = "FormEjercicio29";
            Text = "FormEjercicio29";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtDeporte;
        private ListBox lstDeportes;
        private Button Volver;
        private Button btnLimpiar;
        private Button btnAgregar;
        private Label lblVoley;
        private Label lblFutbol;
        private Label lblAjedrez;
        private Label lblBasquet;
        private Label label1;
        private Label label2;
    }
}