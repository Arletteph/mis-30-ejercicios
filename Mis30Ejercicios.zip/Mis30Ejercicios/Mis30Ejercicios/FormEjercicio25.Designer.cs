﻿namespace Mis30Ejercicios
{
    partial class FormEjercicio25
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtConsumo = new TextBox();
            btnAgregar = new Button();
            btnCalcular = new Button();
            btnLimpiar = new Button();
            button1 = new Button();
            lblContador = new Label();
            lblTotal = new Label();
            lstConsumos = new ListBox();
            label2 = new Label();
            label3 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(189, 73);
            label1.Name = "label1";
            label1.Size = new Size(244, 30);
            label1.TabIndex = 0;
            label1.Text = "Pagos en un Restaurant";
            // 
            // txtConsumo
            // 
            txtConsumo.Location = new Point(265, 152);
            txtConsumo.Name = "txtConsumo";
            txtConsumo.Size = new Size(100, 23);
            txtConsumo.TabIndex = 1;
            // 
            // btnAgregar
            // 
            btnAgregar.BackColor = Color.Pink;
            btnAgregar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            btnAgregar.Location = new Point(348, 229);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(75, 27);
            btnAgregar.TabIndex = 2;
            btnAgregar.Text = "Agregar";
            btnAgregar.UseVisualStyleBackColor = false;
            btnAgregar.Click += btnAgregar_Click;
            // 
            // btnCalcular
            // 
            btnCalcular.BackColor = Color.Pink;
            btnCalcular.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            btnCalcular.Location = new Point(244, 229);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(75, 27);
            btnCalcular.TabIndex = 3;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = false;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnLimpiar
            // 
            btnLimpiar.BackColor = Color.Pink;
            btnLimpiar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            btnLimpiar.Location = new Point(147, 229);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(75, 27);
            btnLimpiar.TabIndex = 4;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = false;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Pink;
            button1.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            button1.Location = new Point(244, 276);
            button1.Name = "button1";
            button1.Size = new Size(75, 27);
            button1.TabIndex = 5;
            button1.Text = "Volver";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // lblContador
            // 
            lblContador.AutoSize = true;
            lblContador.BackColor = Color.Pink;
            lblContador.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblContador.Location = new Point(414, 171);
            lblContador.Name = "lblContador";
            lblContador.Size = new Size(108, 17);
            lblContador.TabIndex = 6;
            lblContador.Text = "Contador: 0/130";
            // 
            // lblTotal
            // 
            lblTotal.AutoSize = true;
            lblTotal.BackColor = Color.Pink;
            lblTotal.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTotal.Location = new Point(416, 129);
            lblTotal.Name = "lblTotal";
            lblTotal.Size = new Size(39, 17);
            lblTotal.TabIndex = 7;
            lblTotal.Text = "Total";
            // 
            // lstConsumos
            // 
            lstConsumos.FormattingEnabled = true;
            lstConsumos.ItemHeight = 15;
            lstConsumos.Location = new Point(3, 40);
            lstConsumos.Name = "lstConsumos";
            lstConsumos.Size = new Size(144, 94);
            lstConsumos.TabIndex = 8;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Pink;
            label2.Location = new Point(3, 22);
            label2.Name = "label2";
            label2.Size = new Size(64, 15);
            label2.TabIndex = 9;
            label2.Text = "Consumos";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Pink;
            label3.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(135, 153);
            label3.Name = "label3";
            label3.Size = new Size(124, 17);
            label3.TabIndex = 10;
            label3.Text = "Ingresar consumos";
            // 
            // FormEjercicio25
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.ejercicio1;
            ClientSize = new Size(637, 355);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(lstConsumos);
            Controls.Add(lblTotal);
            Controls.Add(lblContador);
            Controls.Add(button1);
            Controls.Add(btnLimpiar);
            Controls.Add(btnCalcular);
            Controls.Add(btnAgregar);
            Controls.Add(txtConsumo);
            Controls.Add(label1);
            Name = "FormEjercicio25";
            Text = "FormEjercicio25";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtConsumo;
        private Button btnAgregar;
        private Button btnCalcular;
        private Button btnLimpiar;
        private Button button1;
        private Label lblContador;
        private Label lblTotal;
        private ListBox lstConsumos;
        private Label label2;
        private Label label3;
    }
}