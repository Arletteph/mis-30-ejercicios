﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mis30Ejercicios
{
    public partial class FormEjercicio30 : Form
    {
        private string[] clavesCorrectas = { "tienes", "que ser", "invitado", "para", "ingresar" };
        private int claveActual = 0;
        private bool accesoPermitido = false;
        public FormEjercicio30()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (accesoPermitido)
            {
                lblMensaje.Text = "Ya tienes acceso a la fiesta.";
                return;
            }

            string claveIngresada = txtClave.Text.Trim().ToLower();

            if (claveIngresada == clavesCorrectas[claveActual])
            {
                claveActual++;

                if (claveActual < clavesCorrectas.Length)
                {
                    lblPista.Text = $"Clave {claveActual + 1}: {clavesCorrectas[claveActual].ToUpper()}";
                    txtClave.Clear();
                    txtClave.Focus();
                }
                else
                {
                    accesoPermitido = true;
                    lblMensaje.Text = "BIENVENIDO A LA FIESTA";
                    btnVerificar.Enabled = false;
                }
            }
            else
            {
                lblMensaje.Text = "TE EQUIVOCASTE DE FIESTA";
                btnVerificar.Enabled = false;
            }
        }

        private void btnReiniciar_Click(object sender, EventArgs e)
        {
            claveActual = 0;
            accesoPermitido = false;
            txtClave.Clear();
            lblMensaje.Text = "Mensaje";
            lblPista.Text = "Clave 1: TIENES";
            btnVerificar.Enabled = true;
            txtClave.Focus();
        }

        private void FormEjercicio30_Load(object sender, EventArgs e)
        {
            InitializeComponent();
            lblPista.Text = "Clave 1: TIENES";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close (); 
        }
    }
}
