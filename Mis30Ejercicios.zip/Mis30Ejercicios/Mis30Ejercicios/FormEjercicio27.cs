﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mis30Ejercicios
{
    public partial class FormEjercicio27 : Form
    {
        private double cajaInicial = 371;
        private double totalEgresos = 0;
        private bool procesoTerminado = false;
        public FormEjercicio27()
        {
            InitializeComponent();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (procesoTerminado)
            {
                MessageBox.Show("El proceso ya finalizó. Haz clic en 'Limpiar' para reiniciar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (double.TryParse(txtEgresos.Text, out double egreso))
            {
                if (egreso == -1)
                {
                    procesoTerminado = true;
                    btnAgregar.Enabled = false; // Desactiva el botón
                    lblRestoCaja.Text = $"Saldo final en caja: ${(cajaInicial - totalEgresos) / 100:F2}";
                    MessageBox.Show("Proceso finalizado (se ingresó -1).", "Fin", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                if (egreso < 0)
                {
                    MessageBox.Show("Ingrese un valor positivo o -1 para terminar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                totalEgresos += egreso;
                double restoCaja = cajaInicial - totalEgresos;

                // Mostrar resultados
                lblTotalEgresos.Text = $"Total de egresos: ${totalEgresos / 100:F2}";
                lblRestoCaja.Text = $"Saldo restante: ${restoCaja / 100:F2}";

                // Opcional: agregar a ListBox
                lstEgresos.Items.Add($"Egreso: ${egreso / 100:F2}");

                txtEgresos.Clear();
                txtEgresos.Focus();
            }
            else
            {
                MessageBox.Show("Ingrese un valor numérico válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Volver_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            totalEgresos = 0;
            procesoTerminado = false;
            btnAgregar.Enabled = true;
            txtEgresos.Clear();
            lstEgresos.Items.Clear();
            lblTotalEgresos.Text = "Total de egresos: $0.00";
            lblRestoCaja.Text = "Saldo restante: $3.71";
            txtEgresos.Focus();
        }
    }

}
